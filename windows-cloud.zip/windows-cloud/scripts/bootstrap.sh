#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

if ! command -v docker >/dev/null 2>&1; then
  echo "Docker não foi encontrado. Instale Docker Engine e o plugin Docker Compose primeiro." >&2
  exit 1
fi
if ! docker compose version >/dev/null 2>&1; then
  echo "O plugin Docker Compose v2 não foi encontrado." >&2
  exit 1
fi

if [[ ! -f .env ]]; then
  if ! command -v openssl >/dev/null 2>&1; then echo "O comando openssl é necessário para gerar segredos." >&2; exit 1; fi
  cp .env.example .env
  if [[ "$(id -u)" == "0" ]]; then container_uid=1000; container_gid=1000; else container_uid="$(id -u)"; container_gid="$(id -g)"; fi
  sed -i \
    -e "s/^CONTAINER_UID=.*/CONTAINER_UID=${container_uid}/" \
    -e "s/^CONTAINER_GID=.*/CONTAINER_GID=${container_gid}/" \
    -e "s/^POSTGRES_ADMIN_PASSWORD=.*/POSTGRES_ADMIN_PASSWORD=$(openssl rand -hex 32)/" \
    -e "s/^POSTGRES_APP_PASSWORD=.*/POSTGRES_APP_PASSWORD=$(openssl rand -hex 32)/" \
    -e "s/^SESSION_SECRET=.*/SESSION_SECRET=$(openssl rand -hex 48)/" \
    -e "s/^DATA_ENCRYPTION_KEY=.*/DATA_ENCRYPTION_KEY=$(openssl rand -hex 32)/" \
    -e "s/^GUAC_JSON_SECRET=.*/GUAC_JSON_SECRET=$(openssl rand -hex 16)/" .env
  mkdir -p data/drive
  chmod 750 data
  chmod 770 data/drive
  if [[ "$(id -u)" == "0" ]]; then chown -R 1000:1000 data/drive; fi
  chmod 600 .env
  echo "Arquivo .env criado com segredos aleatórios."
  echo ""
  echo "ANTES DE SUBIR O SERVIÇO, edite .env e configure:"
  echo "  1) DOMAIN com um domínio real que aponte para este servidor (necessário para HTTPS público)."
  echo "  2) AWS_REGION, AWS_SUBNET_ID e AWS_WINDOWS_SECURITY_GROUP_ID."
  echo "  3) A role/permissões AWS do servidor para criar e gerir as instâncias."
  echo "  4) Se usar chaves AWS estáticas como alternativa, mantenha-as somente no .env (0600). Prefira uma IAM role."
  echo ""
  echo "Depois execute novamente: ./scripts/bootstrap.sh"
  exit 0
fi

if grep -q '^DOMAIN=cloud.example.com$' .env; then
  echo "Edite DOMAIN no .env para um domínio real ou localhost para teste local antes de implantar." >&2
  exit 1
fi
if [[ ! -s .env ]]; then echo ".env está vazio." >&2; exit 1; fi
mkdir -p data/drive
chmod 750 data
chmod 770 data/drive
if [[ "$(id -u)" == "0" ]]; then chown -R 1000:1000 data/drive; fi
chmod 600 .env

echo "Validando configuração Compose..."
docker compose config >/dev/null

echo "Baixando imagens e construindo o Windows Cloud..."
docker compose pull db guacd caddy
docker compose build app guac
docker compose up -d
echo ""
echo "Serviços iniciados. Confira: docker compose ps"
echo "Logs: docker compose logs -f app guac caddy"
echo "Abra https://${DOMAIN} depois de apontar o DNS e aguarde o certificado TLS."
echo "ATENÇÃO: uma VM Windows só será provisionada quando você clicar em Ligar meu PC e a AWS estiver configurada. Isso gera custos." 
