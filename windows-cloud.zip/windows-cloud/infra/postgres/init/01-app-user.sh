#!/bin/bash
set -euo pipefail
# POSTGRES_APP_PASSWORD is generated as hex by scripts/bootstrap.sh, so SQL quoting is safe.
psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" <<EOSQL
CREATE ROLE windowscloud_app LOGIN PASSWORD '${POSTGRES_APP_PASSWORD}';
GRANT CONNECT ON DATABASE ${POSTGRES_DB} TO windowscloud_app;
GRANT USAGE, CREATE ON SCHEMA public TO windowscloud_app;
ALTER SCHEMA public OWNER TO windowscloud_app;
EOSQL
