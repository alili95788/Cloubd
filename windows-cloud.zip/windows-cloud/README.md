# Windows Cloud ☁️💻

Projeto web mobile-first para gerenciar e acessar uma máquina Windows licenciada na nuvem usando o navegador Android. O acesso remoto é transmitido por Apache Guacamole + RDP; não é uma animação ou uma réplica visual do Windows.

> **Estado honesto do projeto:** o código de aplicação e a configuração de implantação estão incluídos. Nenhuma VM foi criada neste ambiente, porque isso exige uma conta de nuvem, permissões, configuração de rede, domínio e cobrança. A primeira configuração usa **Windows Server 2022 Desktop Experience licenciado pela AWS**, não afirma que está entregando uma licença de Windows 10/11 cliente. Algumas aplicações podem recusar Windows Server ou exigir GPU/mais RAM.

## O que está implementado

- Interface responsiva, preparada para celular, tablet e PC, com opção PWA para instalar na tela inicial.
- Cadastro/login com hash de senha bcrypt, sessão de servidor em PostgreSQL, cookie `HttpOnly`/`SameSite`, limite de tentativas, validação de origem e eventos de auditoria.
- Provisionamento AWS EC2 Windows, início, parada, reinício e exclusão explícita; armazenamento EBS persistente entre desligamentos.
- Recuperação da senha inicial do Windows via AWS EC2 e armazenamento criptografado com AES-256-GCM. Chaves e credenciais não ficam no frontend.
- Apache Guacamole com extensão JSON autenticada por HMAC-SHA256 + AES-128-CBC para criar um link remoto temporário, limitado à própria máquina do usuário.
- RDP no IP privado da VM. O projeto não pede para expor a porta 3389 à internet.
- Unidade redirecionada `WindowsCloud` via Guacamole para transferir arquivos entre Android e sessão remota.
- Catálogo de programas com links oficiais e aviso para copiar o endereço e abri-lo **dentro do Windows remoto**.
- Páginas AI Lab, Arquivos, Atividade e Central de ajuda.
- Docker Compose, PostgreSQL, Guacamole/guacd, Caddy para HTTPS e documentação de implantação.

## O que ainda exige configuração externa

1. Conta de nuvem e permissão para criar recursos faturáveis.
2. VPC/subnet, grupos de segurança, role IAM e domínio DNS.
3. Decisão de licenciamento e compatibilidade se o requisito for **Windows 10/11 cliente**, em vez de Windows Server.
4. Teste de aceitação real após preencher credenciais e implantar. Esse teste não pode ser declarado concluído neste ambiente sem acesso à conta do provedor.

O catálogo **não** instala programas em silêncio nem finge que uma visita ao site é uma instalação. A instalação é feita dentro da sessão Windows pelo usuário, com os avisos normais do sistema.

## Requisitos no servidor

- Linux x86-64 atualizado, Docker Engine + Docker Compose v2.
- Domínio ou subdomínio apontando para o servidor e portas TCP 80/443 acessíveis.
- Para VM Windows: AWS EC2 na mesma VPC/rede privada alcançável pelo servidor Guacamole e permissões AWS para criar e gerir as instâncias.
- DNS funcionando e tempo do sistema sincronizado.

## Início rápido

1. Extraia o ZIP numa máquina Linux de servidor.
2. Entre na pasta `windows-cloud` e execute:

   ```bash
   ./scripts/bootstrap.sh
   ```

3. O primeiro comando cria `.env` com segredos aleatórios e **para antes de iniciar os serviços**. Edite o arquivo: troque `DOMAIN=cloud.example.com` pelo seu domínio real, e preencha `AWS_REGION`, `AWS_SUBNET_ID` e `AWS_WINDOWS_SECURITY_GROUP_ID`.
4. Configure as permissões IAM no servidor usando uma role/credencial de execução protegida. Não cole chaves AWS em arquivo frontend. Veja [`docs/DEPLOY.md`](docs/DEPLOY.md).
5. Execute `./scripts/bootstrap.sh` novamente. Verifique os serviços com `docker compose ps` e logs com `docker compose logs -f app guac caddy`.
6. Abra `https://SEU-DOMINIO`, crie a conta, depois toque em **Ligar meu PC**. O provisionamento e a primeira inicialização podem demorar vários minutos.

Para interromper os contêineres sem apagar os dados: `docker compose down`. **Não use `docker compose down -v`** se quiser preservar o banco de dados. Os arquivos de transferência ficam em `data/drive/` e o banco em um volume Docker.

## Conta AWS e cobrança

A configuração padrão é `m6i.large` (2 vCPU/8 GiB, se disponível na região) e volume root de 80 GiB gp3. Preço, disponibilidade, licença e impostos variam por região e data. A VM pode gerar cobrança enquanto estiver ligada; o armazenamento persistente normalmente também gera custo enquanto a VM está parada. Configure AWS Budgets/alertas antes de usar. Não existe plano grátis garantido neste projeto.

A conta AWS deve pertencer ao responsável pela implantação. Use permissões mínimas e uma role de servidor sempre que possível; não publique o `.env` nem as chaves privadas.

## Compatibilidade

A implementação usa o parâmetro público de AMI da AWS para **Windows Server 2022 English Full Base**. Isso entrega uma sessão Windows real com interface gráfica, mas não equivale a uma licença de desktop Windows 10/11. A VM não inclui GPU por padrão. Antigravity lista Windows 10 64-bit ou posterior, porém sua compatibilidade específica com Windows Server precisa ser verificada no momento da instalação. Aplicativos de IA podem exigir login, plano ou hardware adicional.

## Pastas principais

```text
windows-cloud/
├── public/                 # interface mobile, PWA e sessão remota embutida
├── server/index.js         # API, autenticação, AWS, arquivos e sessão Guacamole
├── infra/guacamole/        # imagem Guacamole com extensão JSON oficial
├── infra/postgres/init/    # usuário PostgreSQL restrito da aplicação
├── data/drive/             # arquivos transferidos; volume compartilhado app/guacd
├── docs/DEPLOY.md          # passo a passo de implantação
├── docs/SECURITY.md        # limites e hardening
├── docker-compose.yml
├── Caddyfile
└── scripts/bootstrap.sh
```

## Fontes oficiais usadas para a integração

- Apache Guacamole 1.6.0 — [Docker](https://guacamole.apache.org/doc/gug/guacamole-docker.html), [JSON authentication](https://guacamole.apache.org/doc/gug/json-auth.html).
- AWS EC2 — [pares de chaves](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/ec2-key-pairs.html) e [obter senha inicial do Windows](https://docs.aws.amazon.com/cli/latest/reference/ec2/get-password-data.html).
- Google Antigravity — [download/requisitos](https://antigravity.google/download).
- OpenAI Codex — [documentação oficial](https://developers.openai.com/codex/).
- Visual Studio Code — [instalação oficial no Windows](https://code.visualstudio.com/docs/setup/windows).

## Licença do código deste projeto

Consulte [`LICENSE`](LICENSE). Componentes de terceiros mantêm suas próprias licenças (por exemplo, Apache Guacamole sob Apache License 2.0 e imagens de contêiner conforme seus avisos).
