'use strict';

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const state = { user: null, page: 'overview', authMode: 'login', machine: null, cloudConfigured: false, missingConfiguration: [], files: [], apps: [], summary: null, remoteUrl: null, remoteOpen: false, appFilter: 'Todos', appQuery: '', activity: [], refreshTimer: null };
const authView = $('#auth-view');
const appView = $('#app-view');
const pageContent = $('#page-content');
const remoteView = $('#remote-view');
const remoteFrame = $('#remote-frame');
const confirmDialog = $('#confirm-dialog');
let modalAction = null;

function esc(value) {
  return String(value ?? '').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
}
function formatBytes(bytes) {
  const n = Number(bytes || 0);
  if (n < 1024) return `${n} B`;
  if (n < 1024 ** 2) return `${(n / 1024).toFixed(1)} KB`;
  if (n < 1024 ** 3) return `${(n / 1024 ** 2).toFixed(1)} MB`;
  return `${(n / 1024 ** 3).toFixed(2)} GB`;
}
function timeAgo(value) {
  if (!value) return 'Ainda não';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '—';
  return date.toLocaleString('pt-BR', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
}
function toast(message, type = 'ok') {
  const item = document.createElement('div');
  item.className = `toast ${type === 'error' ? 'error' : ''}`;
  item.innerHTML = `<span class="toast-mark">${type === 'error' ? '!' : '✓'}</span><p>${esc(message)}</p><button aria-label="Fechar aviso">×</button>`;
  $('.toast-region').appendChild(item);
  $('button', item).addEventListener('click', () => item.remove());
  setTimeout(() => item.remove(), 6500);
}
async function api(url, options = {}) {
  const config = { credentials: 'same-origin', ...options, headers: { ...(options.headers || {}) } };
  if (config.body && !(config.body instanceof FormData) && typeof config.body !== 'string') {
    config.headers['Content-Type'] = 'application/json';
    config.body = JSON.stringify(config.body);
  }
  const response = await fetch(url, config);
  const contentType = response.headers.get('content-type') || '';
  let body = contentType.includes('application/json') ? await response.json() : await response.text();
  if (!response.ok) {
    const message = typeof body === 'object' && body ? body.error : `Solicitação falhou (${response.status}).`;
    const error = new Error(message || `Erro HTTP ${response.status}`);
    error.status = response.status;
    error.body = body;
    throw error;
  }
  return body;
}
function setAuthMode(mode) {
  state.authMode = mode;
  const register = mode === 'register';
  $('#auth-title').textContent = register ? 'Crie sua conta' : 'Entre na sua conta';
  $('#auth-subtitle').textContent = register ? 'Seu espaço pessoal começa com uma conta.' : 'Continue para acessar seu computador na nuvem.';
  $('#auth-submit').innerHTML = register ? 'Criar conta <span>→</span>' : 'Entrar <span>→</span>';
  $('#auth-toggle-caption').textContent = register ? 'Já tem uma conta?' : 'Ainda não tem conta?';
  $('#auth-toggle').textContent = register ? 'Entrar' : 'Criar conta';
  $('#auth-password').setAttribute('autocomplete', register ? 'new-password' : 'current-password');
}
function showAuth() {
  authView.classList.remove('hidden');
  appView.classList.add('hidden');
  remoteView.classList.add('hidden');
  state.remoteOpen = false;
  if (state.refreshTimer) clearInterval(state.refreshTimer);
  setAuthMode('login');
}
async function enterApp(user) {
  state.user = user;
  authView.classList.add('hidden');
  appView.classList.remove('hidden');
  $('#user-email').textContent = user.email;
  $('#user-avatar').textContent = (user.email || 'WC').slice(0, 2).toUpperCase();
  await Promise.all([refreshMachine(), loadSummary(), loadApps()]);
  navigate('overview');
  if (state.refreshTimer) clearInterval(state.refreshTimer);
  state.refreshTimer = setInterval(() => { if (state.user && !state.remoteOpen) refreshMachine(true).catch(() => {}); }, 15000);
}

$('#auth-toggle').addEventListener('click', () => setAuthMode(state.authMode === 'login' ? 'register' : 'login'));
$('#auth-form').addEventListener('submit', async event => {
  event.preventDefault();
  const button = $('#auth-submit');
  const email = $('#auth-email').value.trim();
  const password = $('#auth-password').value;
  button.disabled = true;
  button.innerHTML = '<span class="spinner"></span> Aguarde';
  try {
    const endpoint = state.authMode === 'register' ? '/api/auth/register' : '/api/auth/login';
    const result = await api(endpoint, { method: 'POST', body: { email, password } });
    $('#auth-password').value = '';
    await enterApp(result.user);
    toast(state.authMode === 'register' ? 'Conta criada. A interface está pronta para configurar o PC na nuvem.' : 'Login realizado. Bem-vindo de volta.');
  } catch (error) { toast(error.message, 'error'); }
  finally { button.disabled = false; setAuthMode(state.authMode); }
});
$('#logout-button').addEventListener('click', async () => {
  try { await api('/api/auth/logout', { method: 'POST', body: {} }); } catch { /* Expired sessions can still return to login. */ }
  state.user = null;
  showAuth();
});

function machineStatusLabel(machine) {
  if (!machine) return state.cloudConfigured ? 'Não criada' : 'Configuração pendente';
  const map = { pending: 'Iniciando', 'running': 'Ligado', 'stopping': 'Desligando', 'stopped': 'Desligado', 'shutting-down': 'Desligando', 'terminated': 'Encerrado', 'rebooting': 'Reiniciando', 'missing': 'Não encontrado', 'unknown': 'Desconhecido' };
  return map[machine.state] || machine.state || 'Desconhecido';
}
function updateConnectionPill() {
  const pill = $('#connection-pill');
  const label = pill.querySelector('span');
  pill.className = 'status-pill';
  if (!state.cloudConfigured) {
    pill.classList.add('warn'); label.textContent = 'Nuvem não configurada';
  } else if (state.machine?.state === 'running' && state.machine?.windowsPasswordReady) {
    pill.classList.add('good'); label.textContent = 'PC disponível';
  } else if (state.machine) {
    pill.classList.add('warn'); label.textContent = machineStatusLabel(state.machine);
  } else { label.textContent = 'PC ainda não criado'; }
}
function updateOverview() {
  updateConnectionPill();
  if (!$('#stat-machine-state')) return;
  const machine = state.machine;
  $('#stat-machine-state').textContent = machineStatusLabel(machine);
  $('#stat-machine-desc').textContent = machine ? `${machine.instanceType} · ${machine.region}` : state.cloudConfigured ? 'Nenhuma VM vinculada' : 'Configure o provedor primeiro';
  $('#stat-disk').textContent = `${machine?.volumeGiB || state.summary?.volumeDefaultGiB || 80} GB`;
  const metrics = machine?.metrics || {};
  if ($('#stat-cpu')) $('#stat-cpu').textContent = metrics.cpuPercent == null ? '—' : `${metrics.cpuPercent}%`;
  if ($('#stat-ram')) $('#stat-ram').textContent = metrics.ramPercent == null ? 'Agente pendente' : `${metrics.ramPercent}%`;
  if ($('#stat-network')) $('#stat-network').textContent = metrics.networkInBytes == null && metrics.networkOutBytes == null ? '—' : `↓ ${formatBytes(metrics.networkInBytes || 0)} / ↑ ${formatBytes(metrics.networkOutBytes || 0)}`;
  $('#stat-files').textContent = `${state.summary?.fileCount || 0} ${Number(state.summary?.fileCount || 0) === 1 ? 'arquivo' : 'arquivos'}`;
  $('#stat-files-desc').textContent = `${formatBytes(state.summary?.transferBytes || 0)} na área de transferência`;
  $('#stat-last-connected').textContent = timeAgo(machine?.lastConnectedAt);
  $('#machine-state-title').innerHTML = machine ? (machine.state === 'running' ? 'Seu computador está ligado.' : machine.state === 'stopped' ? 'Seu PC está desligado.' : ['pending', 'stopping', 'shutting-down', 'rebooting'].includes(machine.state) ? 'Seu computador está mudando de estado.' : 'Sua máquina precisa de atenção.') : 'Seu espaço está pronto<br>para configurar.';
  $('#machine-state-copy').textContent = !state.cloudConfigured
    ? `A interface está pronta. Falta vincular AWS, rede privada, regras de acesso e domínio HTTPS. ${state.missingConfiguration.length ? 'Variáveis ausentes: ' + state.missingConfiguration.join(', ') + '.' : ''}`
    : !machine ? 'Crie seu computador remoto persistente. A primeira inicialização leva alguns minutos e pode gerar cobrança no provedor.'
      : machine.state === 'running' ? (machine.windowsPasswordReady ? 'Windows está ligado. Conecte-se pelo navegador e use seus aplicativos na sessão remota.' : 'Windows está iniciando os serviços iniciais. A senha remota ainda está sendo preparada pela AWS.')
        : machine.state === 'stopped' ? 'A máquina está desligada. Seus dados na unidade persistente ficam guardados até você excluir a máquina.'
          : `Estado informado pelo provedor: ${machine.state}. Esta tela atualiza automaticamente.`;
  const start = $('#start-machine');
  const connect = $('#connect-machine');
  const stop = $('#stop-machine');
  const reboot = $('#reboot-machine');
  start.disabled = !state.cloudConfigured || Boolean(machine && ['running', 'pending', 'stopping', 'shutting-down', 'rebooting'].includes(machine.state));
  start.innerHTML = (machine && ['pending', 'rebooting'].includes(machine.state)) ? '<span class="spinner"></span> Inicializando…' : '<span class="button-glyph">⏻</span> Ligar meu PC';
  connect.disabled = !(state.cloudConfigured && machine?.state === 'running' && machine?.windowsPasswordReady);
  stop.classList.toggle('hidden', !machine || !['running', 'pending', 'rebooting'].includes(machine.state));
  if (reboot) reboot.classList.toggle('hidden', !machine || machine.state !== 'running');
  $('#setup-notice').classList.toggle('hidden', state.cloudConfigured && machine);
  $('#last-updated').textContent = `Atualizado ${new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}`;
}
async function refreshMachine(silent = false) {
  if (!state.user) return;
  try {
    const result = await api('/api/machine');
    state.machine = result.machine;
    state.cloudConfigured = result.cloudConfigured;
    state.missingConfiguration = result.missingConfiguration || [];
    updateOverview();
  } catch (error) { if (!silent) toast(error.message, 'error'); }
}
async function loadSummary() {
  if (!state.user) return;
  try { state.summary = await api('/api/summary'); updateOverview(); } catch (error) { console.warn(error); }
}
async function loadApps() {
  try { const response = await api('/api/catalog'); state.apps = response.apps || []; }
  catch { state.apps = []; }
}
$('#refresh-button').addEventListener('click', async () => {
  $('#refresh-button').style.transform = 'rotate(180deg)';
  await Promise.all([refreshMachine(), loadSummary()]);
  setTimeout(() => $('#refresh-button').style.transform = '', 250);
  toast('Estado atualizado.');
});
$('#start-machine').addEventListener('click', async () => {
  const button = $('#start-machine');
  button.disabled = true;
  $('#machine-feedback').textContent = 'Enviando solicitação ao provedor de nuvem…';
  try {
    const result = await api('/api/machine/start', { method: 'POST', body: {} });
    $('#machine-feedback').textContent = result.message || 'Solicitação enviada.';
    toast(result.message || 'Solicitação enviada.');
    await refreshMachine(true);
  } catch (error) {
    $('#machine-feedback').textContent = error.message;
    toast(error.message, 'error');
  } finally { updateOverview(); }
});
$('#stop-machine').addEventListener('click', () => openModal({
  title: 'Desligar o computador?', message: 'Salve seus arquivos antes de desligar. A unidade persistente será mantida, mas a cobrança do provedor depende do tipo de recurso e do armazenamento.',
  confirmLabel: 'Solicitar desligamento', action: async () => {
    const result = await api('/api/machine/stop', { method: 'POST', body: {} });
    toast(result.message); await refreshMachine(true);
  }
}));
$('#connect-machine').addEventListener('click', async () => {
  const button = $('#connect-machine');
  button.disabled = true;
  try {
    const result = await api('/api/machine/connect', { method: 'POST', body: {} });
    state.remoteUrl = result.url;
    remoteFrame.src = result.url;
    remoteView.classList.remove('hidden');
    state.remoteOpen = true;
    $('#remote-session-status').textContent = `Sessão temporária · até ${result.expiresInHours}h`;
    document.body.style.overflow = 'hidden';
    setTimeout(() => $('#remote-mobile-hint').classList.add('hidden'), 8000);
  } catch (error) { toast(error.message, 'error'); }
  finally { updateOverview(); }
});
function closeRemote() {
  remoteFrame.src = 'about:blank';
  remoteView.classList.add('hidden');
  state.remoteOpen = false;
  document.body.style.overflow = '';
  if (state.user) refreshMachine(true).catch(() => {});
}
$('#remote-close').addEventListener('click', closeRemote);
$('#remote-fullscreen').addEventListener('click', async () => {
  try { if (!document.fullscreenElement) await remoteView.requestFullscreen(); else await document.exitFullscreen(); }
  catch { toast('A tela cheia não está disponível neste navegador.', 'error'); }
});
$('#remote-keyboard').addEventListener('click', () => { remoteFrame.focus(); try { remoteFrame.contentWindow.focus(); } catch {} toast('Toque em um campo dentro do Windows para abrir o teclado do Android.'); });
$('#remote-hide-toolbar').addEventListener('click', () => { $('#remote-toolbar').classList.add('hidden'); $('#remote-show-toolbar').classList.remove('hidden'); });
$('#remote-show-toolbar').addEventListener('click', () => { $('#remote-toolbar').classList.remove('hidden'); $('#remote-show-toolbar').classList.add('hidden'); });
let remoteWasOffline = false;
window.addEventListener('offline', () => { if (state.remoteOpen) { remoteWasOffline = true; $('#remote-session-status').textContent = 'Internet interrompida · aguardando reconexão'; } });
window.addEventListener('online', () => { if (state.remoteOpen && remoteWasOffline && state.remoteUrl) { remoteWasOffline = false; $('#remote-session-status').textContent = 'Internet restaurada · reconectando…'; remoteFrame.src = state.remoteUrl; setTimeout(() => { if (state.remoteOpen) $('#remote-session-status').textContent = 'Sessão remota · reconectada'; }, 2500); } });

function navLabel(page) {
  return ({ overview: 'Visão geral', apps: 'Aplicativos', ai: 'AI Lab', files: 'Arquivos', activity: 'Atividade', help: 'Central de ajuda' })[page] || 'Visão geral';
}
function navigate(page) {
  state.page = page;
  $$('.nav-item').forEach(item => item.classList.toggle('active', item.dataset.page === page));
  $('#page-title').textContent = navLabel(page);
  $('#sidebar').classList.remove('mobile-open');
  if (page === 'overview') { pageContent.innerHTML = overviewTemplate(); updateOverview(); }
  else if (page === 'apps') renderApps();
  else if (page === 'ai') renderAI();
  else if (page === 'files') renderFiles();
  else if (page === 'activity') renderActivity();
  else if (page === 'help') renderHelp();
  bindCommonNavigation();
}
function overviewTemplate() {
  return `<section class="welcome-row"><div><p class="date-line">SEU ESPAÇO DIGITAL</p><h1>Seu computador na nuvem<span class="title-dot">.</span></h1><p class="page-lede">Ligue seu PC remoto, continue seu trabalho e gerencie seus arquivos.</p></div><div class="secure-tag"><span>◇</span> Sessão individual</div></section>
    <section class="pc-hero card"><div class="pc-hero-glow"></div><div class="pc-hero-main"><div class="pc-kicker"><span class="tiny-square">W</span> WINDOWS CLOUD PC</div><h2 id="machine-state-title">Carregando estado…</h2><p id="machine-state-copy">Consultando provedor de nuvem.</p><div class="pc-actions"><button id="start-machine" class="button primary"><span class="button-glyph">⏻</span> Ligar meu PC</button><button id="connect-machine" class="button secondary" disabled><span class="button-glyph">↗</span> Conectar ao Windows</button><button id="reboot-machine" class="button ghost hidden">Reiniciar</button><button id="stop-machine" class="button ghost hidden">Desligar</button></div><div id="machine-feedback" class="inline-feedback" role="status"></div></div>${monitorArtwork()}</section>
    <section class="section-heading"><div><h2>Visão do sistema</h2><p>Dados reportados pelo backend, sem métricas simuladas.</p></div><span class="updated-label" id="last-updated">Consultando…</span></section>
    <section class="stats-grid">${statTemplate('▣','blue','ESTADO DA MÁQUINA','stat-machine-state','Não criada','stat-machine-desc','Sem VM vinculada')}${statTemplate('▤','violet','DISCO DA VM','stat-disk','80 GB','','Volume persistente · AWS EBS')}${statTemplate('◉','blue','CPU · MÉDIA 5 MIN','stat-cpu','—','','Métrica EC2 / CloudWatch')}${statTemplate('▦','violet','MEMÓRIA RAM','stat-ram','Agente pendente','','Exige CloudWatch Agent no Windows')}${statTemplate('⇅','cyan','REDE · ÚLTIMO PERÍODO','stat-network','—','','Entrada / saída reportada por CloudWatch')}${statTemplate('⇅','cyan','ARQUIVOS TRANSFERIDOS','stat-files','0 arquivos','stat-files-desc','0 B usados na área de transferência')}${statTemplate('◷','amber','ÚLTIMA CONEXÃO','stat-last-connected','Ainda não','','Horário informado pela API')}</section>
    <section class="section-heading section-heading-gap"><div><h2>Comece por aqui</h2><p>Atalhos para as tarefas mais comuns.</p></div></section>
    <section class="quick-grid"><button class="quick-card card" data-goto="apps"><span class="quick-symbol app-symbol">▦</span><span><b>Encontrar programas</b><small>Fontes oficiais e requisitos</small></span><span class="quick-arrow">↗</span></button><button class="quick-card card" data-goto="ai"><span class="quick-symbol ai-symbol">✳</span><span><b>Explorar AI Lab</b><small>Ferramentas para programar</small></span><span class="quick-arrow">↗</span></button><button class="quick-card card" data-goto="files"><span class="quick-symbol file-symbol">▤</span><span><b>Transferir arquivos</b><small>Celular ↔ área WindowsCloud</small></span><span class="quick-arrow">↗</span></button></section>
    <section id="setup-notice" class="notice-card"><div class="notice-icon">i</div><div><b>Infraestrutura ainda não vinculada</b><p>A interface está pronta, mas iniciar um PC real exige configurar a conta do provedor, a rede privada, permissões e o domínio HTTPS. Consulte o guia incluído no projeto.</p><button id="show-setup" class="text-button">Ver o que falta configurar ↗</button></div></section><footer class="page-footer"><span>Windows Cloud <span class="footer-version">v0.1</span></span><span>Seus dados. Sua sessão. Seu controle.</span></footer>`;
}
function monitorArtwork() {
  return `<div class="pc-illustration" aria-hidden="true"><div class="monitor-frame"><div class="monitor-screen"><div class="windows-mark"><i></i><i></i><i></i><i></i></div><div class="screen-line"></div><div class="screen-line short"></div><div class="screen-taskbar"><i></i><i></i><i></i></div></div><div class="monitor-neck"></div><div class="monitor-foot"></div></div><div class="orbit orbit-one"></div><div class="orbit orbit-two"></div><span class="floating-chip chip-cloud">☁ <span>Cloud PC</span></span><span class="floating-chip chip-secure">◇ <span>Isolado</span></span></div>`;
}
function statTemplate(icon, color, label, valueId, value, footId, foot) {
  return `<article class="stat-card card"><div class="stat-top"><span class="stat-icon ${color}">${icon}</span><span class="stat-label">${label}</span></div><div id="${valueId}" class="stat-value">${value}</div><div ${footId ? `id="${footId}"` : ''} class="stat-foot">${foot}</div></article>`;
}
function bindCommonNavigation() {
  $$('[data-goto]').forEach(button => button.addEventListener('click', () => navigate(button.dataset.goto)));
  const showSetup = $('#show-setup');
  if (showSetup) showSetup.addEventListener('click', () => navigate('help'));
  const helpButton = $('#help-button');
  if (helpButton) helpButton.onclick = () => navigate('help');
  const newStart = $('#start-machine');
  if (newStart && !newStart.dataset.bound) { newStart.dataset.bound = '1'; newStart.addEventListener('click', async () => {
    newStart.disabled = true;
    const feedback = $('#machine-feedback'); if (feedback) feedback.textContent = 'Enviando solicitação ao provedor de nuvem…';
    try { const result = await api('/api/machine/start', { method: 'POST', body: {} }); if (feedback) feedback.textContent = result.message || ''; toast(result.message || 'Solicitação enviada.'); await refreshMachine(true); }
    catch (error) { if (feedback) feedback.textContent = error.message; toast(error.message, 'error'); }
    finally { updateOverview(); }
  }); }
  const newConnect = $('#connect-machine');
  if (newConnect && !newConnect.dataset.bound) { newConnect.dataset.bound = '1'; newConnect.addEventListener('click', async () => {
    newConnect.disabled = true;
    try { const result = await api('/api/machine/connect', { method: 'POST', body: {} }); state.remoteUrl = result.url; remoteFrame.src = result.url; remoteView.classList.remove('hidden'); state.remoteOpen = true; $('#remote-session-status').textContent = `Sessão temporária · até ${result.expiresInHours}h`; document.body.style.overflow = 'hidden'; setTimeout(() => $('#remote-mobile-hint').classList.add('hidden'), 8000); }
    catch (error) { toast(error.message, 'error'); }
    finally { updateOverview(); }
  }); }
  const newReboot = $('#reboot-machine');
  if (newReboot && !newReboot.dataset.bound) { newReboot.dataset.bound = '1'; newReboot.addEventListener('click', () => openModal({ title: 'Reiniciar o computador?', message: 'O acesso remoto será interrompido brevemente. Salve seus arquivos antes de continuar.', confirmLabel: 'Reiniciar PC', action: async () => { const result = await api('/api/machine/reboot', { method: 'POST', body: {} }); toast(result.message); await refreshMachine(true); } })); }
  const newStop = $('#stop-machine');
  if (newStop && !newStop.dataset.bound) { newStop.dataset.bound = '1'; newStop.addEventListener('click', () => openModal({ title: 'Desligar o computador?', message: 'Salve os arquivos antes de desligar. A unidade persistente será mantida; o custo do provedor depende do recurso e do armazenamento.', confirmLabel: 'Solicitar desligamento', action: async () => { const result = await api('/api/machine/stop', { method: 'POST', body: {} }); toast(result.message); await refreshMachine(true); } })); }
}
$$('.nav-item').forEach(item => item.addEventListener('click', () => navigate(item.dataset.page)));
$$('[data-goto]').forEach(item => item.addEventListener('click', () => navigate(item.dataset.goto)));
$('#mobile-menu').addEventListener('click', () => $('#sidebar').classList.toggle('mobile-open'));
document.addEventListener('click', event => {
  if (window.innerWidth <= 900 && !event.target.closest('#sidebar') && !event.target.closest('#mobile-menu')) $('#sidebar').classList.remove('mobile-open');
});

const appCategoryList = ['Todos', 'IA e programação', 'Programação', 'Navegadores', 'Design', 'Produtividade'];
function iconFor(app) {
  const map = { antigravity: 'AG', codex: 'CX', vscode: 'VS', git: 'GIT', python: 'PY', node: 'JS', chrome: 'CH', gitlab: 'GH', blender: '3D', libreoffice: 'LO' };
  return map[app.id] || 'APP';
}
function appsTemplate(apps, aiMode = false) {
  const visible = apps.filter(app => {
    const query = (state.appQuery || '').toLowerCase();
    const text = `${app.name} ${app.category} ${app.description} ${app.kind}`.toLowerCase();
    return (!query || text.includes(query)) && (aiMode ? ['antigravity', 'codex'].includes(app.id) : state.appFilter === 'Todos' || app.category === state.appFilter);
  });
  const webTools = aiMode ? [
    { id:'chatgpt-web',name:'ChatGPT',category:'IA pelo navegador',kind:'Conta ChatGPT',description:'Acesse a experiência web oficial; recursos disponíveis dependem da conta e do plano.',url:'https://chatgpt.com/',badge:'WEB' },
    { id:'gemini-web',name:'Google Gemini',category:'IA pelo navegador',kind:'Conta Google',description:'Assistente de IA pelo navegador, sem instalar um programa Windows.',url:'https://gemini.google.com/',badge:'WEB' },
    { id:'claude-web',name:'Claude',category:'IA pelo navegador',kind:'Conta Claude',description:'Assistente de IA acessado pela web; alguns recursos podem exigir plano.',url:'https://claude.ai/',badge:'WEB' }
  ].filter(app => !state.appQuery || `${app.name} ${app.description}`.toLowerCase().includes(state.appQuery.toLowerCase())) : [];
  return `${visible.map(app => appCard(app)).join('')}${webTools.map(app => appCard(app)).join('')}${visible.length + webTools.length ? '' : '<div class="empty-state"><strong>Nenhum aplicativo encontrado</strong>Tente outra palavra ou categoria.</div>'}`;
}
function appCard(app) {
  return `<article class="app-card card"><div class="app-card-top"><div class="app-logo">${esc(iconFor(app))}</div><div><h3>${esc(app.name)}</h3><span class="app-category">${esc(app.category)}</span></div></div><p class="app-description">${esc(app.description)}</p><div class="app-meta">${esc(app.kind)} · Fonte oficial</div><div class="app-card-actions"><a class="button secondary" href="${esc(app.url)}" target="_blank" rel="noopener noreferrer">Site oficial ↗</a><button class="copy-link" data-copy-url="${esc(app.url)}">Copiar link</button></div></article>`;
}
function renderApps() {
  pageContent.innerHTML = `<section class="content-header"><div><h1>Aplicativos</h1><p>Catálogo com links oficiais. Para baixar no PC remoto, copie o link e cole no navegador dentro da sessão Windows; abrir um link aqui acessa o site pelo celular.</p></div><label class="search-box"><span>⌕</span><input id="app-search" type="search" placeholder="Buscar programas…" value="${esc(state.appQuery)}" aria-label="Buscar programas"></label></section><div class="filter-row">${appCategoryList.map(item => `<button class="filter-chip ${state.appFilter === item ? 'active' : ''}" data-filter="${esc(item)}">${esc(item)}</button>`).join('')}</div><section id="app-grid" class="app-grid">${appsTemplate(state.apps)}</section><div class="catalog-note"><b>Nota sobre instalações:</b> os links direcionam para fontes oficiais. A plataforma não declara um programa instalado só porque o site foi aberto. Confirme arquitetura, requisitos, conta e licença dentro do Windows remoto antes de instalar.</div><footer class="page-footer"><span>Catálogo de referências oficiais</span><span>As páginas podem mudar com o tempo.</span></footer>`;
  $('#app-search').addEventListener('input', event => { state.appQuery = event.target.value; $('#app-grid').innerHTML = appsTemplate(state.apps); bindCopyLinks(); });
  $$('[data-filter]').forEach(button => button.addEventListener('click', () => { state.appFilter = button.dataset.filter; renderApps(); }));
  bindCopyLinks();
}
function renderAI() {
  const selected = state.apps.filter(app => ['antigravity', 'codex'].includes(app.id));
  pageContent.innerHTML = `<section class="content-header"><div><p class="date-line">AI LAB · FERRAMENTAS DE CRIAÇÃO</p><h1>Um laboratório para suas ideias.</h1><p>Descubra ferramentas de IA instaláveis no Windows e opções que rodam no navegador. Requisitos e disponibilidade mudam; consulte sempre a fonte oficial.</p></div></section><section class="section-heading"><div><h2>Programas para o Windows</h2><p>Baixe os instaladores oficiais dentro do PC remoto.</p></div></section><section class="app-grid">${appsTemplate(selected, true)}</section><section class="section-heading section-heading-gap"><div><h2>Ferramentas pelo navegador</h2><p>Não exigem instalação no Windows, mas podem pedir login ou assinatura.</p></div></section><section class="app-grid">${appsTemplate([], true)}</section><div class="catalog-note"><b>Sobre compatibilidade:</b> esta configuração da AWS cria Windows Server com área de trabalho, não uma licença de Windows 10/11 doméstico. Verifique os requisitos atuais: algumas ferramentas podem não suportar Windows Server ou podem exigir GPU, memória adicional e credenciais próprias.</div>`;
  // Avoid duplicate listing: show desktop tools in the first row, web tools in the second.
  const rows = $$('.app-grid', pageContent);
  rows[0].innerHTML = selected.map(app => appCard(app)).join('');
  rows[1].innerHTML = [
    { id:'chatgpt-web',name:'ChatGPT',category:'IA pelo navegador',kind:'Conta ChatGPT',description:'Assistente pela web; os recursos dependem da conta e do plano.',url:'https://chatgpt.com/' },
    { id:'gemini-web',name:'Google Gemini',category:'IA pelo navegador',kind:'Conta Google',description:'Assistente pelo navegador sem instalar um programa Windows.',url:'https://gemini.google.com/' },
    { id:'claude-web',name:'Claude',category:'IA pelo navegador',kind:'Conta Claude',description:'Assistente de IA na web; alguns recursos podem exigir plano.',url:'https://claude.ai/' }
  ].map(app => appCard(app)).join('');
  bindCopyLinks();
}
function bindCopyLinks() {
  $$('[data-copy-url]').forEach(button => button.addEventListener('click', async () => {
    const url = button.dataset.copyUrl;
    try { await navigator.clipboard.writeText(url); toast('Link oficial copiado. Abra o navegador dentro do Windows remoto e cole o endereço.'); }
    catch { toast(`Copie este endereço para o Windows: ${url}`, 'error'); }
  }));
}

async function renderFiles() {
  pageContent.innerHTML = `<section class="content-header"><div><h1>Arquivos na nuvem</h1><p>Envie arquivos do celular para a unidade compartilhada WindowsCloud. Ela aparece como unidade redirecionada no Explorador de Arquivos da sessão RDP/Guacamole; não é uma leitura direta de todo o disco C:.</p></div></section><section class="file-layout"><div class="files-panel card"><div class="panel-title-row"><div><h2>Área de transferência</h2><p id="file-count-text">Consultando arquivos…</p></div><button id="file-refresh" class="icon-button" title="Atualizar arquivos">⟳</button></div><div class="upload-zone"><span class="upload-symbol">↑</span><b>Enviar um arquivo do celular</b><p>O arquivo será disponibilizado pela unidade compartilhada WindowsCloud na sessão remota.</p><label class="button secondary" for="upload-file">Escolher arquivo</label><input type="file" id="upload-file"><p id="upload-state" role="status">Limite por arquivo: ${Math.round((100 * 1024 * 1024) / 1024 / 1024)} MB (configurável no servidor).</p></div><div id="file-list" class="file-list" style="margin-top:14px"><div class="empty-message">Carregando…</div></div></div><aside class="transfer-instructions card"><h3>Como encontrar os arquivos no Windows</h3><div class="step-list"><div class="step-row"><span class="step-num">1</span><div><b>Abra a sessão remota</b><p>Ligue a máquina e toque em “Conectar ao Windows”.</p></div></div><div class="step-row"><span class="step-num">2</span><div><b>Abra o Explorador de Arquivos</b><p>Entre em “Este Computador” e procure a unidade ou pasta de rede “WindowsCloud”.</p></div></div><div class="step-row"><span class="step-num">3</span><div><b>Copie os arquivos para o PC</b><p>Copie da unidade WindowsCloud para Documentos, Downloads ou outra pasta da máquina virtual.</p></div></div></div><div class="quota-label"><span>Uso da área compartilhada</span><b id="quota-value">—</b></div><div class="progress-track"><div id="quota-progress" class="progress-fill"></div></div><p id="quota-caption" class="quota-caption">A cota é configurada pelo administrador da implantação. O disco principal da VM é separado desta área.</p></aside></section><footer class="page-footer"><span>Transferências por sessão individual</span><span>Confirme o arquivo antes de compartilhar ou excluir.</span></footer>`;
  $('#file-refresh').addEventListener('click', renderFiles);
  $('#upload-file').addEventListener('change', uploadSelectedFile);
  await loadFilesIntoPage();
}
async function loadFilesIntoPage() {
  try {
    const result = await api('/api/files');
    state.files = result.files || [];
    const sum = state.files.reduce((total, file) => total + Number(file.sizeBytes || file.size_bytes || 0), 0);
    $('#file-count-text').textContent = `${state.files.length} ${state.files.length === 1 ? 'arquivo' : 'arquivos'} · ${formatBytes(sum)}`;
    $('#file-list').innerHTML = state.files.length ? state.files.map(file => {
      const name = file.original_name || file.originalName || 'Arquivo';
      const size = Number(file.sizeBytes ?? file.size_bytes ?? 0);
      const date = file.created_at || file.createdAt;
      const ext = (name.split('.').pop() || 'FILE').slice(0, 4).toUpperCase();
      return `<div class="file-row"><span class="file-type">${esc(ext)}</span><span class="file-info"><b title="${esc(name)}">${esc(name)}</b><small>${formatBytes(size)} · ${esc(timeAgo(date))}</small></span><span class="file-actions"><a class="file-action" href="/api/files/${encodeURIComponent(file.id)}/download" title="Baixar no celular" aria-label="Baixar ${esc(name)}">↓</a><button class="file-action delete" data-delete-file="${esc(file.id)}" data-file-name="${esc(name)}" title="Excluir arquivo" aria-label="Excluir ${esc(name)}">×</button></span></div>`;
    }).join('') : '<div class="empty-message">Ainda não há arquivos transferidos.<br>Envie um arquivo para começar.</div>';
    const quota = state.summary?.quotaBytes || 2 * 1024 ** 3;
    $('#quota-value').textContent = `${formatBytes(sum)} / ${formatBytes(quota)}`;
    $('#quota-progress').style.width = `${Math.min(100, quota ? sum / quota * 100 : 0)}%`;
    $('#quota-caption').textContent = `Uso ${Math.min(100, quota ? Math.round(sum / quota * 100) : 0)}% da área compartilhada. A cota configurada é ${formatBytes(quota)}; o disco principal do Windows é separado.`;
    bindFileActions();
    loadSummary();
  } catch (error) {
    $('#file-list').innerHTML = `<div class="empty-message">Não foi possível listar os arquivos: ${esc(error.message)}</div>`;
  }
}
async function uploadSelectedFile(event) {
  const file = event.target.files?.[0];
  if (!file) return;
  const label = $('#upload-state');
  label.innerHTML = '<span class="spinner"></span> Enviando arquivo…';
  const data = new FormData(); data.append('file', file);
  try {
    await api('/api/files', { method: 'POST', body: data });
    toast(`Arquivo “${file.name}” enviado para a área compartilhada.`);
    label.textContent = 'Envio concluído. Abra a unidade WindowsCloud dentro da sessão remota.';
    await loadFilesIntoPage();
  } catch (error) { label.textContent = error.message; toast(error.message, 'error'); }
  finally { event.target.value = ''; }
}
function bindFileActions() {
  $$('[data-delete-file]').forEach(button => button.addEventListener('click', () => openModal({
    title: 'Excluir este arquivo?', message: `Para confirmar, digite exatamente o nome do arquivo: ${button.dataset.fileName}`,
    inputLabel: button.dataset.fileName, placeholder: 'Digite o nome completo do arquivo', confirmLabel: 'Excluir arquivo', danger: true,
    action: async value => {
      await api(`/api/files/${encodeURIComponent(button.dataset.deleteFile)}`, { method: 'DELETE', body: { confirmation: value } });
      toast('Arquivo excluído da área compartilhada.'); await loadFilesIntoPage();
    }
  })));
}

async function renderActivity() {
  pageContent.innerHTML = `<section class="content-header"><div><h1>Atividade</h1><p>Eventos importantes registrados pelo backend nesta conta.</p></div><button id="activity-refresh" class="button secondary">Atualizar eventos ⟳</button></section><section class="files-panel card"><div id="activity-list" class="activity-list"><div class="empty-message">Carregando eventos…</div></div></section>`;
  $('#activity-refresh').addEventListener('click', renderActivity);
  try {
    const result = await api('/api/events'); state.activity = result.events || [];
    $('#activity-list').innerHTML = state.activity.length ? state.activity.map(event => `<div class="activity-row ${event.level === 'warning' ? 'warning' : ''}"><span class="activity-dot"></span><div><b>${esc(event.action)}</b><p>${esc(event.detail)}</p><time>${esc(timeAgo(event.created_at))}</time></div></div>`).join('') : '<div class="empty-message">Ainda não há eventos registrados.</div>';
  } catch (error) { $('#activity-list').innerHTML = `<div class="empty-message">${esc(error.message)}</div>`; }
}
function renderHelp() {
  pageContent.innerHTML = `<section class="content-header"><div><h1>Central de ajuda</h1><p>Passos práticos para transformar o projeto em um serviço real. O repositório não cria uma conta AWS nem uma VM sem suas permissões.</p></div></section><section class="help-grid"><article class="help-card card"><h3>1. Preparar o servidor</h3><p>Use um servidor Linux com Docker Compose, um domínio que aponte para ele e portas 80/443 liberadas. Configure HTTPS antes de criar contas reais.</p><ul><li>Execute <span class="inline-code">scripts/bootstrap.sh</span>.</li><li>Edite o arquivo <span class="inline-code">.env</span> gerado.</li><li>Veja <span class="inline-code">docs/DEPLOY.md</span> no ZIP.</li></ul></article><article class="help-card card"><h3>2. Preparar a AWS</h3><p>Crie uma VPC e subnet privada para as máquinas Windows. O servidor Linux precisa ter rota privada até a subnet.</p><ul><li>Uma regra permite TCP 3389 apenas do security group do servidor Guacamole.</li><li>Não exponha RDP (3389) à internet.</li><li>Defina orçamento/alertas de custo no provedor.</li></ul></article><article class="help-card card"><h3>3. Conectar pelo Android</h3><p>Entre nesta aplicação pelo Chrome atualizado. Ligue o PC e aguarde até a credencial do Windows estar pronta.</p><ul><li>Toque em “Conectar ao Windows”.</li><li>Use teclado e toque dentro da sessão.</li><li>Para desconectar sem desligar, volte ao painel. O Windows permanece ligado e pode continuar gerando custo.</li></ul></article><article class="help-card card"><h3>4. Compatibilidade e licenças</h3><p>A configuração padrão cria Windows Server 2022 Desktop Experience com cobrança da licença via AWS. Ela não se apresenta como Windows 10/11 cliente.</p><ul><li>Antigravity publica requisito de Windows 10 64-bit ou posterior; a compatibilidade específica com Windows Server precisa ser validada.</li><li>Codex e outros produtos podem exigir conta, subscrição ou configurações próprias.</li><li>Não há promessa de GPU ou de aceleração gráfica.</li></ul></article></section><section class="section-heading section-heading-gap"><div><h2>Ações avançadas</h2><p>Operações irreversíveis exigem confirmação explícita.</p></div></section><section class="notice-card"><div class="notice-icon">!</div><div><b>Excluir a máquina e os arquivos</b><p>Esta operação solicita a terminação da VM, remove a associação da conta e apaga os arquivos na área compartilhada. A conclusão da exclusão no provedor pode levar alguns minutos. Faça backup do que precisar.</p><button id="destroy-machine" class="button danger">Apagar minha máquina e arquivos</button></div></section><footer class="page-footer"><span>Consulte README.md e docs/DEPLOY.md</span><span>Não coloque segredos no frontend.</span></footer>`;
  $('#destroy-machine').addEventListener('click', () => openModal({
    title: 'Excluir máquina e arquivos?', message: 'Isso solicita o encerramento da máquina remota e apaga também os arquivos enviados para a área de transferência. Esta ação não pode ser desfeita. Digite a frase exata para confirmar.',
    inputLabel: 'APAGAR MINHA MÁQUINA E ARQUIVOS', placeholder: 'Digite a frase de confirmação', confirmLabel: 'Apagar permanentemente', danger: true,
    action: async value => { await api('/api/machine/destroy', { method: 'POST', body: { confirmation: value } }); toast('Exclusão solicitada.'); await Promise.all([refreshMachine(true), loadSummary()]); navigate('overview'); }
  }));
}

function openModal(options) {
  $('#modal-title').textContent = options.title || 'Confirmar ação';
  $('#modal-copy').textContent = options.message || 'Deseja continuar?';
  const extra = $('#modal-extra');
  extra.innerHTML = options.inputLabel ? `<input id="modal-input" type="text" autocomplete="off" placeholder="${esc(options.placeholder || options.inputLabel)}" aria-label="Confirmação" data-required="${esc(options.inputLabel)}">` : '';
  const confirmButton = $('#modal-confirm');
  confirmButton.textContent = options.confirmLabel || 'Confirmar';
  confirmButton.className = `button ${options.danger ? 'danger' : 'primary'}`;
  modalAction = options.action;
  confirmDialog.showModal();
}
$('#modal-confirm').addEventListener('click', async event => {
  event.preventDefault();
  const input = $('#modal-input');
  const entered = input?.value || '';
  if (input && entered !== input.dataset.required) { toast('O texto de confirmação não corresponde.', 'error'); return; }
  const action = modalAction;
  $('#modal-confirm').disabled = true;
  try { if (action) await action(entered); confirmDialog.close('confirmed'); }
  catch (error) { toast(error.message, 'error'); }
  finally { $('#modal-confirm').disabled = false; }
});

async function init() {
  $('#today-label').textContent = new Intl.DateTimeFormat('pt-BR', { weekday: 'long', day: '2-digit', month: 'long' }).format(new Date()).toUpperCase();
  try {
    const result = await api('/api/auth/me');
    await enterApp(result.user);
  } catch { showAuth(); }
  bindCommonNavigation();
}
init();
