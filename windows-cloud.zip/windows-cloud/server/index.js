'use strict';

require('dotenv').config();
const express = require('express');
const session = require('express-session');
const PgSession = require('connect-pg-simple')(session);
const { Pool } = require('pg');
const bcrypt = require('bcryptjs');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const multer = require('multer');
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const forge = require('node-forge');
const {
  EC2Client, CreateKeyPairCommand, DeleteKeyPairCommand, RunInstancesCommand, DescribeInstancesCommand,
  StartInstancesCommand, StopInstancesCommand, RebootInstancesCommand,
  TerminateInstancesCommand, DescribeImagesCommand, GetPasswordDataCommand
} = require('@aws-sdk/client-ec2');
const { SSMClient, GetParameterCommand } = require('@aws-sdk/client-ssm');
const { CloudWatchClient, GetMetricStatisticsCommand } = require('@aws-sdk/client-cloudwatch');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const NODE_ENV = process.env.NODE_ENV || 'development';
const DATA_ROOT = path.resolve(process.env.DRIVE_ROOT || '/drive');
const MAX_UPLOAD_MB = Number(process.env.MAX_UPLOAD_MB || 100);
const MAX_UPLOAD = MAX_UPLOAD_MB * 1024 * 1024;
const DRIVE_QUOTA = Number(process.env.DRIVE_QUOTA_GB || 2) * 1024 * 1024 * 1024;
const pg = new Pool({ connectionString: process.env.DATABASE_URL, max: 12, idleTimeoutMillis: 30000 });
const region = process.env.AWS_REGION || 'us-east-1';
const ec2 = new EC2Client({ region });
const ssm = new SSMClient({ region });
const cloudwatch = new CloudWatchClient({ region });

const catalog = [
  { id: 'antigravity', name: 'Google Antigravity', category: 'AI e programação', kind: 'Windows x64/ARM64', description: 'Ambiente de desenvolvimento com agentes de IA. Confira requisitos e conta necessária no site oficial.', url: 'https://antigravity.google/download', badge: 'IA' },
  { id: 'codex', name: 'OpenAI Codex', category: 'IA e programação', kind: 'Aplicativo / CLI', description: 'Ferramentas oficiais Codex. A disponibilidade da experiência depende do produto, da conta e dos requisitos atuais.', url: 'https://developers.openai.com/codex/', badge: 'IA' },
  { id: 'vscode', name: 'Visual Studio Code', category: 'Programação', kind: 'Windows x64/ARM64', description: 'Editor leve com extensões, terminal integrado e ferramentas de desenvolvimento.', url: 'https://code.visualstudio.com/download', badge: 'DEV' },
  { id: 'git', name: 'Git for Windows', category: 'Programação', kind: 'Windows', description: 'Controle de versão para projetos e repositórios de código.', url: 'https://git-scm.com/download/win', badge: 'DEV' },
  { id: 'python', name: 'Python', category: 'Programação', kind: 'Windows', description: 'Linguagem e runtime para scripts, automação e IA.', url: 'https://www.python.org/downloads/windows/', badge: 'DEV' },
  { id: 'node', name: 'Node.js', category: 'Programação', kind: 'Windows', description: 'Runtime JavaScript para desenvolvimento web e ferramentas de linha de comando.', url: 'https://nodejs.org/en/download', badge: 'DEV' },
  { id: 'chrome', name: 'Google Chrome', category: 'Navegadores', kind: 'Windows', description: 'Navegador para usar serviços web na máquina remota.', url: 'https://www.google.com/chrome/', badge: 'WEB' },
  { id: 'gitlab', name: 'GitHub Desktop', category: 'Produtividade', kind: 'Windows', description: 'Interface visual para trabalhar com repositórios Git.', url: 'https://desktop.github.com/', badge: 'APP' },
  { id: 'blender', name: 'Blender', category: 'Design', kind: 'Windows', description: 'Criação 3D. Projetos grandes podem exigir GPU e mais memória.', url: 'https://www.blender.org/download/', badge: '3D' },
  { id: 'libreoffice', name: 'LibreOffice', category: 'Produtividade', kind: 'Windows', description: 'Suíte de escritório gratuita.', url: 'https://www.libreoffice.org/download/download-libreoffice/', badge: 'APP' }
];

function configuredSecret(name, bytes) {
  const value = process.env[name] || '';
  return new RegExp(`^[a-fA-F0-9]{${bytes * 2}}$`).test(value) ? Buffer.from(value, 'hex') : null;
}
const encryptionKey = configuredSecret('DATA_ENCRYPTION_KEY', 32);
const guacJsonKey = configuredSecret('GUAC_JSON_SECRET', 16);
const awsConfigured = Boolean(process.env.AWS_SUBNET_ID && process.env.AWS_WINDOWS_SECURITY_GROUP_ID && process.env.AWS_REGION);
const missingAws = [];
if (!process.env.AWS_SUBNET_ID) missingAws.push('AWS_SUBNET_ID');
if (!process.env.AWS_WINDOWS_SECURITY_GROUP_ID) missingAws.push('AWS_WINDOWS_SECURITY_GROUP_ID');
if (!process.env.AWS_REGION) missingAws.push('AWS_REGION');

function encryptSecret(value) {
  if (!encryptionKey) throw new Error('DATA_ENCRYPTION_KEY ausente ou inválida. Execute scripts/bootstrap.sh.');
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', encryptionKey, iv);
  const encrypted = Buffer.concat([cipher.update(String(value), 'utf8'), cipher.final()]);
  return [iv, cipher.getAuthTag(), encrypted].map(b => b.toString('base64url')).join('.');
}
function decryptSecret(value) {
  if (!encryptionKey || !value) throw new Error('Segredo criptografado indisponível.');
  const [iv, tag, encrypted] = value.split('.').map(v => Buffer.from(v, 'base64url'));
  const decipher = crypto.createDecipheriv('aes-256-gcm', encryptionKey, iv);
  decipher.setAuthTag(tag);
  return Buffer.concat([decipher.update(encrypted), decipher.final()]).toString('utf8');
}
function makeGuacData(payload) {
  if (!guacJsonKey) throw new Error('GUAC_JSON_SECRET ausente ou inválida. Execute scripts/bootstrap.sh.');
  const raw = Buffer.from(JSON.stringify(payload), 'utf8');
  const signature = crypto.createHmac('sha256', guacJsonKey).update(raw).digest();
  const signed = Buffer.concat([signature, raw]);
  const cipher = crypto.createCipheriv('aes-128-cbc', guacJsonKey, Buffer.alloc(16, 0));
  return Buffer.concat([cipher.update(signed), cipher.final()]).toString('base64');
}

async function initDb() {
  await pg.query(`
    CREATE TABLE IF NOT EXISTS users (
      id UUID PRIMARY KEY,
      email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS machines (
      id UUID PRIMARY KEY,
      user_id UUID NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
      instance_id TEXT NOT NULL,
      region TEXT NOT NULL,
      instance_type TEXT NOT NULL,
      key_name TEXT NOT NULL,
      key_material_enc TEXT NOT NULL,
      admin_password_enc TEXT,
      private_ip INET,
      state TEXT NOT NULL DEFAULT 'pending',
      last_connected_at TIMESTAMPTZ,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS cloud_files (
      id UUID PRIMARY KEY,
      user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      original_name TEXT NOT NULL,
      storage_name TEXT NOT NULL,
      mime_type TEXT NOT NULL DEFAULT 'application/octet-stream',
      size_bytes BIGINT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE INDEX IF NOT EXISTS cloud_files_user_idx ON cloud_files(user_id, created_at DESC);
    CREATE TABLE IF NOT EXISTS audit_events (
      id BIGSERIAL PRIMARY KEY,
      user_id UUID,
      level TEXT NOT NULL,
      action TEXT NOT NULL,
      detail TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
  `);
}

async function audit(userId, level, action, detail) {
  try { await pg.query('INSERT INTO audit_events(user_id, level, action, detail) VALUES($1,$2,$3,$4)', [userId || null, level, action, String(detail).slice(0, 500)]); }
  catch (e) { console.error('audit log failed:', e.message); }
}
function asyncRoute(fn) { return (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next); }
function requireAuth(req, res, next) {
  if (!req.session || !req.session.userId) return res.status(401).json({ error: 'Entre na sua conta para continuar.' });
  next();
}
function sanitizeOriginalName(name) {
  const normalized = path.basename(String(name || 'arquivo')).replace(/[\\/\0]/g, '').replace(/[^\p{L}\p{N} .()_\-]/gu, '_').trim();
  return (normalized || 'arquivo').slice(0, 180);
}
function userDrive(userId) {
  const folder = path.resolve(DATA_ROOT, String(userId));
  if (!folder.startsWith(DATA_ROOT + path.sep)) throw new Error('Caminho inválido.');
  return folder;
}

app.disable('x-powered-by');
app.set('trust proxy', 1);
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"], scriptSrc: ["'self'"], styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
      fontSrc: ["'self'", 'https://fonts.gstatic.com', 'data:'],
      imgSrc: ["'self'", 'data:'], connectSrc: ["'self'", 'ws:', 'wss:'],
      frameSrc: ["'self'"], objectSrc: ["'none'"], baseUri: ["'self'"], formAction: ["'self'"]
    }
  }, crossOriginEmbedderPolicy: false
}));
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: false, limit: '1mb' }));
app.use((req, res, next) => {
  if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method) && req.get('origin')) {
    try {
      if (new URL(req.get('origin')).host !== req.get('host')) return res.status(403).json({ error: 'Origem da solicitação inválida.' });
    } catch { return res.status(403).json({ error: 'Origem da solicitação inválida.' }); }
  }
  next();
});
app.use(session({
  store: new PgSession({ pool: pg, tableName: 'user_sessions', createTableIfMissing: true, pruneSessionInterval: 900 }),
  name: 'wc.sid', secret: process.env.SESSION_SECRET || 'development-secret-change-this-value',
  resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, secure: NODE_ENV === 'production', sameSite: 'lax', maxAge: 1000 * 60 * 60 * 12 }
}));
app.use('/api/', rateLimit({ windowMs: 15 * 60 * 1000, limit: 180, standardHeaders: 'draft-8', legacyHeaders: false }));
const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 8, standardHeaders: 'draft-8', legacyHeaders: false, message: { error: 'Muitas tentativas. Aguarde um pouco e tente novamente.' } });

app.get('/api/health', asyncRoute(async (req, res) => {
  await pg.query('SELECT 1');
  res.json({ ok: true, service: 'Windows Cloud', version: '0.1.0', cloudConfigured: awsConfigured, remoteConfigured: Boolean(guacJsonKey), now: new Date().toISOString() });
}));

app.post('/api/auth/register', authLimiter, asyncRoute(async (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) return res.status(400).json({ error: 'Digite um e-mail válido.' });
  if (password.length < 10 || password.length > 128) return res.status(400).json({ error: 'Use uma senha com pelo menos 10 caracteres (máximo 128).' });
  if (!encryptionKey || !guacJsonKey) return res.status(503).json({ error: 'O servidor ainda não foi configurado. Execute scripts/bootstrap.sh e configure o .env.' });
  const id = crypto.randomUUID();
  try {
    const hash = await bcrypt.hash(password, 12);
    await pg.query('INSERT INTO users(id,email,password_hash) VALUES($1,$2,$3)', [id, email, hash]);
    await fs.promises.mkdir(userDrive(id), { recursive: true, mode: 0o770 });
    await new Promise((resolve, reject) => req.session.regenerate(err => err ? reject(err) : resolve()));
    req.session.userId = id;
    req.session.email = email;
    await audit(id, 'info', 'account.register', 'Conta criada');
    res.status(201).json({ user: { id, email } });
  } catch (e) {
    if (e.code === '23505') return res.status(409).json({ error: 'Já existe uma conta com esse e-mail.' });
    throw e;
  }
}));

app.post('/api/auth/login', authLimiter, asyncRoute(async (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  const { rows } = await pg.query('SELECT id,email,password_hash FROM users WHERE email=$1', [email]);
  if (!rows.length || !(await bcrypt.compare(password, rows[0].password_hash))) {
    await audit(null, 'warning', 'account.login.failed', `Tentativa inválida para ${email.slice(0, 180)}`);
    return res.status(401).json({ error: 'E-mail ou senha incorretos.' });
  }
  await new Promise((resolve, reject) => req.session.regenerate(err => err ? reject(err) : resolve()));
  req.session.userId = rows[0].id;
  req.session.email = rows[0].email;
  await audit(rows[0].id, 'info', 'account.login', 'Login realizado');
  res.json({ user: { id: rows[0].id, email: rows[0].email } });
}));

app.post('/api/auth/logout', requireAuth, asyncRoute(async (req, res) => {
  const id = req.session.userId;
  await audit(id, 'info', 'account.logout', 'Sessão encerrada');
  req.session.destroy(err => {
    if (err) return res.status(500).json({ error: 'Não foi possível encerrar a sessão.' });
    res.clearCookie('wc.sid', { httpOnly: true, secure: NODE_ENV === 'production', sameSite: 'lax' });
    res.json({ ok: true });
  });
}));
app.get('/api/auth/me', requireAuth, asyncRoute(async (req, res) => {
  const { rows } = await pg.query('SELECT id,email,created_at FROM users WHERE id=$1', [req.session.userId]);
  if (!rows.length) return res.status(401).json({ error: 'Conta não encontrada.' });
  res.json({ user: rows[0] });
}));

async function fetchMachine(userId) {
  const { rows } = await pg.query('SELECT * FROM machines WHERE user_id=$1', [userId]);
  return rows[0] || null;
}
async function describeMachine(machine) {
  const out = await ec2.send(new DescribeInstancesCommand({ InstanceIds: [machine.instance_id] }));
  return out.Reservations?.[0]?.Instances?.[0] || null;
}
function tcpProbe(host, port = 3389, timeoutMs = 1800) {
  return new Promise(resolve => {
    const socket = net.createConnection({ host, port });
    let settled = false;
    const finish = result => { if (settled) return; settled = true; socket.destroy(); resolve(result); };
    socket.setTimeout(timeoutMs, () => finish(false));
    socket.once('connect', () => finish(true));
    socket.once('error', () => finish(false));
  });
}

function decryptWindowsPassword(passwordData, privateKeyPem) {
  const privateKey = forge.pki.privateKeyFromPem(privateKeyPem);
  const binaryCipher = Buffer.from(passwordData, 'base64').toString('binary');
  const plaintext = privateKey.decrypt(binaryCipher, 'RSAES-PKCS1-V1_5');
  return plaintext;
}
async function refreshMachine(userId) {
  let machine = await fetchMachine(userId);
  if (!machine || !awsConfigured) return { machine, instance: null, providerConfigured: awsConfigured };
  let instance;
  try { instance = await describeMachine(machine); }
  catch (e) {
    if (e.name === 'InvalidInstanceID.NotFound') return { machine: { ...machine, state: 'missing' }, instance: null, providerConfigured: true };
    throw e;
  }
  if (!instance) return { machine: { ...machine, state: 'missing' }, instance: null, providerConfigured: true };
  const state = instance.State?.Name || 'unknown';
  const privateIp = instance.PrivateIpAddress || null;
  await pg.query('UPDATE machines SET state=$1, private_ip=$2, updated_at=NOW() WHERE id=$3', [state, privateIp, machine.id]);
  machine = { ...machine, state, private_ip: privateIp };
  if (state === 'running' && !machine.admin_password_enc && machine.key_material_enc) {
    try {
      const result = await ec2.send(new GetPasswordDataCommand({ InstanceId: machine.instance_id }));
      if (result.PasswordData) {
        const pem = decryptSecret(machine.key_material_enc);
        const password = decryptWindowsPassword(result.PasswordData, pem);
        const encrypted = encryptSecret(password);
        await pg.query('UPDATE machines SET admin_password_enc=$1, updated_at=NOW() WHERE id=$2', [encrypted, machine.id]);
        machine.admin_password_enc = encrypted;
        await audit(userId, 'info', 'machine.password.ready', 'Credencial inicial do Windows recuperada e armazenada cifrada');
      }
    } catch (e) {
      // The password is often not available for several minutes after first boot.
      console.warn('Windows password is not ready yet:', e.message);
    }
  }
  return { machine, instance, providerConfigured: true };
}

async function createMachine(userId, oldMachine = null) {
  if (!awsConfigured) {
    const error = new Error(`Infraestrutura AWS incompleta. Configure: ${missingAws.join(', ')}. Consulte docs/DEPLOY.md.`);
    error.status = 503; error.code = 'cloud_not_configured'; throw error;
  }
  if (!encryptionKey || !guacJsonKey) {
    const error = new Error('DATA_ENCRYPTION_KEY ou GUAC_JSON_SECRET ausente/inválida. Execute scripts/bootstrap.sh e mantenha as chaves geradas.');
    error.status = 503; error.code = 'secrets_not_configured'; throw error;
  }
  const instanceType = process.env.AWS_INSTANCE_TYPE || 'm6i.large';
  const amiParameter = process.env.AWS_WINDOWS_AMI_PARAMETER || '/aws/service/ami-windows-latest/Windows_Server-2022-English-Full-Base';
  const amiResp = await ssm.send(new GetParameterCommand({ Name: amiParameter }));
  const amiId = amiResp.Parameter?.Value;
  if (!amiId) throw new Error(`Não foi possível resolver a AMI Windows pelo parâmetro ${amiParameter}.`);
  const image = await ec2.send(new DescribeImagesCommand({ ImageIds: [amiId] }));
  const rootDevice = image.Images?.[0]?.RootDeviceName || '/dev/sda1';
  const keyName = `wc-${userId.slice(0, 8)}-${Date.now().toString(36)}`;
  let keyCreated = false;
  let launchedInstanceId = null;
  try {
    const key = await ec2.send(new CreateKeyPairCommand({ KeyName: keyName, KeyType: 'rsa', KeyFormat: 'pem' }));
    keyCreated = true;
    const run = await ec2.send(new RunInstancesCommand({
      ImageId: amiId, InstanceType: instanceType, MinCount: 1, MaxCount: 1, KeyName: keyName,
      NetworkInterfaces: [{ DeviceIndex: 0, SubnetId: process.env.AWS_SUBNET_ID, Groups: [process.env.AWS_WINDOWS_SECURITY_GROUP_ID], AssociatePublicIpAddress: false, DeleteOnTermination: true }],
      BlockDeviceMappings: [{ DeviceName: rootDevice, Ebs: { VolumeSize: Number(process.env.AWS_VOLUME_GIB || 80), VolumeType: 'gp3', Encrypted: true, DeleteOnTermination: true } }],
      TagSpecifications: [
        { ResourceType: 'instance', Tags: [{ Key: 'Name', Value: `WindowsCloud-${userId.slice(0, 8)}` }, { Key: 'WindowsCloudUserId', Value: userId }, { Key: 'ManagedBy', Value: 'WindowsCloud' }] },
        { ResourceType: 'volume', Tags: [{ Key: 'WindowsCloudUserId', Value: userId }, { Key: 'ManagedBy', Value: 'WindowsCloud' }] }
      ]
    }));
    const instance = run.Instances?.[0];
    if (!instance?.InstanceId) throw new Error('A AWS não retornou o identificador da máquina.');
    launchedInstanceId = instance.InstanceId;
    const row = {
      id: oldMachine?.id || crypto.randomUUID(), userId, instanceId: instance.InstanceId,
      keyName, keyMaterialEnc: encryptSecret(key.KeyMaterial), instanceType
    };
    if (oldMachine) {
      await pg.query(`UPDATE machines SET instance_id=$1, region=$2, instance_type=$3, key_name=$4, key_material_enc=$5,
        admin_password_enc=NULL, private_ip=$6, state=$7, updated_at=NOW() WHERE id=$8`,
        [row.instanceId, region, instanceType, keyName, row.keyMaterialEnc, instance.PrivateIpAddress || null, instance.State?.Name || 'pending', oldMachine.id]);
      if (oldMachine.key_name) {
        try { await ec2.send(new DeleteKeyPairCommand({ KeyName: oldMachine.key_name })); }
        catch (cleanupError) { console.warn('Could not delete previous AWS key pair:', cleanupError.message); }
      }
    } else {
      await pg.query(`INSERT INTO machines(id,user_id,instance_id,region,instance_type,key_name,key_material_enc,private_ip,state)
        VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
        [row.id, userId, row.instanceId, region, instanceType, keyName, row.keyMaterialEnc, instance.PrivateIpAddress || null, instance.State?.Name || 'pending']);
    }
    await audit(userId, 'info', 'machine.provision', `Instância ${instance.InstanceId} criada (${instanceType}, AMI ${amiId})`);
    return { id: row.id, instanceId: row.instanceId, state: instance.State?.Name || 'pending', instanceType, region, volumeGiB: Number(process.env.AWS_VOLUME_GIB || 80) };
  } catch (e) {
    console.error('AWS provisioning failed:', e.message);
    if (launchedInstanceId) {
      try { await ec2.send(new TerminateInstancesCommand({ InstanceIds: [launchedInstanceId] })); }
      catch (cleanupError) { console.error('Could not terminate incomplete VM:', cleanupError.message); }
    }
    if (keyCreated) {
      try { await ec2.send(new DeleteKeyPairCommand({ KeyName: keyName })); }
      catch (cleanupError) { console.error('Could not delete incomplete key pair:', cleanupError.message); }
    }
    throw e;
  }
}

async function readCloudMetrics(instanceId, state) {
  const metrics = { cpuPercent: null, ramPercent: null, networkInBytes: null, networkOutBytes: null, note: 'RAM exige CloudWatch Agent no Windows; métricas da EC2 podem levar alguns minutos.' };
  if (state !== 'running') return metrics;
  const start = new Date(Date.now() - 20 * 60 * 1000);
  const end = new Date();
  async function latest(metricName, statistic, unit) {
    try {
      const response = await cloudwatch.send(new GetMetricStatisticsCommand({
        Namespace: 'AWS/EC2', MetricName: metricName,
        Dimensions: [{ Name: 'InstanceId', Value: instanceId }],
        StartTime: start, EndTime: end, Period: 300, Statistics: [statistic], Unit: unit
      }));
      const point = (response.Datapoints || []).filter(item => item[statistic] != null).sort((a,b) => new Date(b.Timestamp) - new Date(a.Timestamp))[0];
      return point ? Number(point[statistic]) : null;
    } catch (e) { console.warn(`CloudWatch metric ${metricName} unavailable:`, e.message); return null; }
  }
  const [cpu, incoming, outgoing] = await Promise.all([
    latest('CPUUtilization', 'Average', 'Percent'),
    latest('NetworkIn', 'Sum', 'Bytes'),
    latest('NetworkOut', 'Sum', 'Bytes')
  ]);
  metrics.cpuPercent = cpu == null ? null : Math.round(cpu * 10) / 10;
  metrics.networkInBytes = incoming;
  metrics.networkOutBytes = outgoing;
  return metrics;
}

async function mapMachine(machine, instance) {
  if (!machine) return null;
  const volumes = instance?.BlockDeviceMappings?.map(x => x.Ebs?.VolumeId).filter(Boolean) || [];
  const machineState = machine.state || instance?.State?.Name || 'unknown';
  const metrics = await readCloudMetrics(machine.instance_id, machineState);
  return {
    id: machine.id, instanceId: machine.instance_id, region: machine.region,
    state: machineState, privateIp: machine.private_ip || instance?.PrivateIpAddress || null,
    instanceType: machine.instance_type, volumeGiB: Number(process.env.AWS_VOLUME_GIB || 80), volumeIds: volumes,
    createdAt: machine.created_at, lastConnectedAt: machine.last_connected_at,
    windowsPasswordReady: Boolean(machine.admin_password_enc),
    osName: 'Windows Server 2022 (Desktop Experience)',
    metrics
  };
}

app.get('/api/machine', requireAuth, asyncRoute(async (req, res) => {
  const { machine, instance } = await refreshMachine(req.session.userId);
  res.json({ machine: await mapMachine(machine, instance), cloudConfigured: awsConfigured, missingConfiguration: missingAws, remoteConfigured: Boolean(guacJsonKey), instanceTypeDefault: process.env.AWS_INSTANCE_TYPE || 'm6i.large', volumeDefaultGiB: Number(process.env.AWS_VOLUME_GIB || 80) });
}));
app.post('/api/machine/start', requireAuth, asyncRoute(async (req, res) => {
  const userId = req.session.userId;
  let machine = await fetchMachine(userId);
  if (machine) {
    let instance;
    try { instance = await describeMachine(machine); }
    catch (e) { if (e.name !== 'InvalidInstanceID.NotFound') throw e; }
    const state = instance?.State?.Name;
    if (state === 'stopped') {
      await ec2.send(new StartInstancesCommand({ InstanceIds: [machine.instance_id] }));
      await pg.query("UPDATE machines SET state='pending',updated_at=NOW() WHERE id=$1", [machine.id]);
      await audit(userId, 'info', 'machine.start', `Inicialização solicitada para ${machine.instance_id}`);
      return res.json({ ok: true, state: 'pending', message: 'Inicialização solicitada. O Windows pode levar alguns minutos.' });
    }
    if (state && !['terminated', 'shutting-down'].includes(state)) return res.json({ ok: true, state, message: 'A máquina já está iniciando ou ligada.' });
    const created = await createMachine(userId, machine);
    return res.json({ ok: true, ...created, message: 'Nova máquina criada; o Windows está iniciando.' });
  }
  const created = await createMachine(userId, null);
  res.status(202).json({ ok: true, ...created, message: 'Máquina criada. A primeira inicialização pode levar vários minutos.' });
}));
app.post('/api/machine/stop', requireAuth, asyncRoute(async (req, res) => {
  const machine = await fetchMachine(req.session.userId);
  if (!machine) return res.status(404).json({ error: 'Você ainda não tem uma máquina.' });
  await ec2.send(new StopInstancesCommand({ InstanceIds: [machine.instance_id] }));
  await audit(req.session.userId, 'info', 'machine.stop', `Parada solicitada para ${machine.instance_id}`);
  res.json({ ok: true, state: 'stopping', message: 'Desligamento solicitado. Salve seus arquivos antes de desligar.' });
}));
app.post('/api/machine/reboot', requireAuth, asyncRoute(async (req, res) => {
  const machine = await fetchMachine(req.session.userId);
  if (!machine) return res.status(404).json({ error: 'Você ainda não tem uma máquina.' });
  await ec2.send(new RebootInstancesCommand({ InstanceIds: [machine.instance_id] }));
  await audit(req.session.userId, 'info', 'machine.reboot', `Reinicialização solicitada para ${machine.instance_id}`);
  res.json({ ok: true, state: 'rebooting', message: 'Reinicialização solicitada.' });
}));
app.post('/api/machine/connect', requireAuth, asyncRoute(async (req, res) => {
  const userId = req.session.userId;
  const { machine, instance } = await refreshMachine(userId);
  if (!awsConfigured) return res.status(503).json({ error: `Configure a infraestrutura AWS primeiro: ${missingAws.join(', ')}. Veja docs/DEPLOY.md.` });
  if (!guacJsonKey) return res.status(503).json({ error: 'Apache Guacamole ainda não foi configurado. Execute scripts/bootstrap.sh.' });
  if (!machine || !instance) return res.status(409).json({ error: 'Crie sua máquina antes de conectar.' });
  if (instance.State?.Name !== 'running') return res.status(409).json({ error: `A máquina está ${instance.State?.Name || 'indisponível'}. Ligue-a e aguarde a inicialização.` });
  if (!machine.admin_password_enc) return res.status(409).json({ error: 'O Windows ainda está preparando a credencial inicial. Atualize o estado em alguns minutos.' });
  const ip = instance.PrivateIpAddress || machine.private_ip;
  if (!ip) return res.status(409).json({ error: 'A máquina ainda não recebeu um endereço de rede privado.' });
  if (!(await tcpProbe(ip, 3389))) return res.status(409).json({ error: 'O Windows ainda não está aceitando conexões RDP. Aguarde um pouco e tente novamente.' });
  const drivePath = userDrive(userId);
  await fs.promises.mkdir(drivePath, { recursive: true, mode: 0o770 });
  await pg.query('UPDATE machines SET last_connected_at=NOW() WHERE id=$1', [machine.id]);
  const password = decryptSecret(machine.admin_password_enc);
  const tokenHours = Math.max(1, Math.min(12, Number(process.env.REMOTE_TOKEN_HOURS || 8)));
  const data = makeGuacData({
    username: `wc-${userId.slice(0, 8)}`,
    expires: Date.now() + (tokenHours * 60 * 60 * 1000),
    connections: {
      windows: {
        protocol: 'rdp',
        parameters: {
          hostname: ip, port: '3389', username: 'Administrator', password,
          'ignore-cert': 'true', security: 'any', 'resize-method': 'display-update',
          'enable-drive': 'true', 'drive-path': drivePath, 'drive-name': 'WindowsCloud',
          'create-drive-path': 'true', 'enable-clipboard': 'true', 'color-depth': '24'
        }
      }
    }
  });
  await audit(userId, 'info', 'machine.connect', 'Link de sessão remota temporário criado');
  res.json({ url: `/guacamole/?data=${encodeURIComponent(data)}`, expiresInHours: tokenHours });
}));
app.post('/api/machine/destroy', requireAuth, asyncRoute(async (req, res) => {
  if (req.body?.confirmation !== 'APAGAR MINHA MÁQUINA E ARQUIVOS') return res.status(400).json({ error: 'Confirmação exata necessária para apagar a máquina e os arquivos.' });
  const userId = req.session.userId;
  const machine = await fetchMachine(userId);
  if (machine) {
    try { await ec2.send(new TerminateInstancesCommand({ InstanceIds: [machine.instance_id] })); }
    catch (e) { if (e.name !== 'InvalidInstanceID.NotFound') throw e; }
    await pg.query('DELETE FROM machines WHERE id=$1', [machine.id]);
    try { await ec2.send(new DeleteKeyPairCommand({ KeyName: machine.key_name })); } catch (e) { console.warn('Could not delete AWS key pair:', e.message); }
  }
  await pg.query('DELETE FROM cloud_files WHERE user_id=$1', [userId]);
  await fs.promises.rm(userDrive(userId), { recursive: true, force: true });
  await fs.promises.mkdir(userDrive(userId), { recursive: true, mode: 0o770 });
  await audit(userId, 'warning', 'machine.destroy', 'Máquina e área de transferência removidas por solicitação explícita');
  res.json({ ok: true, message: 'Solicitação de exclusão enviada. A remoção completa na nuvem pode levar alguns minutos.' });
}));

app.get('/api/catalog', requireAuth, (req, res) => res.json({ apps: catalog }));
app.get('/api/summary', requireAuth, asyncRoute(async (req, res) => {
  const { rows: [files] } = await pg.query('SELECT COUNT(*)::int AS count, COALESCE(SUM(size_bytes),0)::bigint AS bytes FROM cloud_files WHERE user_id=$1', [req.session.userId]);
  const machine = await fetchMachine(req.session.userId);
  res.json({ fileCount: files.count, transferBytes: Number(files.bytes), quotaBytes: DRIVE_QUOTA, machineExists: Boolean(machine), plan: 'Pessoal / infraestrutura própria' });
}));

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    try { fs.mkdirSync(userDrive(req.session.userId), { recursive: true, mode: 0o700 }); cb(null, userDrive(req.session.userId)); }
    catch (e) { cb(e); }
  },
  filename: (req, file, cb) => cb(null, `${crypto.randomUUID()}${path.extname(sanitizeOriginalName(file.originalname)).slice(0, 20)}`)
});
const upload = multer({ storage, limits: { fileSize: MAX_UPLOAD, files: 1 }, fileFilter: (req, file, cb) => cb(null, !file.originalname.includes('\0')) });
app.get('/api/files', requireAuth, asyncRoute(async (req, res) => {
  const { rows } = await pg.query('SELECT id,original_name,mime_type,size_bytes,created_at FROM cloud_files WHERE user_id=$1 ORDER BY created_at DESC', [req.session.userId]);
  res.json({ files: rows.map(f => ({ ...f, sizeBytes: Number(f.size_bytes) })) });
}));
app.post('/api/files', requireAuth, upload.single('file'), asyncRoute(async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Escolha um arquivo para enviar.' });
  const userId = req.session.userId;
  const { rows: [usage] } = await pg.query('SELECT COALESCE(SUM(size_bytes),0)::bigint AS total FROM cloud_files WHERE user_id=$1', [userId]);
  if (Number(usage.total) + req.file.size > DRIVE_QUOTA) {
    await fs.promises.rm(req.file.path, { force: true });
    return res.status(413).json({ error: 'A área de transferência atingiu o limite de armazenamento configurado.' });
  }
  const id = crypto.randomUUID();
  const originalName = sanitizeOriginalName(req.file.originalname);
  try {
    const { rows: [record] } = await pg.query(`INSERT INTO cloud_files(id,user_id,original_name,storage_name,mime_type,size_bytes)
      VALUES($1,$2,$3,$4,$5,$6) RETURNING id,original_name,mime_type,size_bytes,created_at`,
      [id, userId, originalName, req.file.filename, req.file.mimetype || 'application/octet-stream', req.file.size]);
    await audit(userId, 'info', 'file.upload', `Arquivo enviado para a área WindowsCloud: ${originalName}`);
    res.status(201).json({ file: { ...record, sizeBytes: Number(record.size_bytes) } });
  } catch (e) { await fs.promises.rm(req.file.path, { force: true }); throw e; }
}));
app.get('/api/files/:id/download', requireAuth, asyncRoute(async (req, res) => {
  const { rows } = await pg.query('SELECT * FROM cloud_files WHERE id=$1 AND user_id=$2', [req.params.id, req.session.userId]);
  if (!rows.length) return res.status(404).json({ error: 'Arquivo não encontrado.' });
  const file = rows[0];
  const fullPath = path.resolve(userDrive(req.session.userId), file.storage_name);
  if (!fullPath.startsWith(userDrive(req.session.userId) + path.sep)) return res.status(400).json({ error: 'Caminho inválido.' });
  res.download(fullPath, file.original_name);
}));
app.delete('/api/files/:id', requireAuth, asyncRoute(async (req, res) => {
  const { rows } = await pg.query('SELECT * FROM cloud_files WHERE id=$1 AND user_id=$2', [req.params.id, req.session.userId]);
  if (!rows.length) return res.status(404).json({ error: 'Arquivo não encontrado.' });
  if (req.body?.confirmation !== rows[0].original_name) return res.status(400).json({ error: 'Confirme o nome do arquivo para excluí-lo.' });
  await fs.promises.rm(path.resolve(userDrive(req.session.userId), rows[0].storage_name), { force: true });
  await pg.query('DELETE FROM cloud_files WHERE id=$1 AND user_id=$2', [req.params.id, req.session.userId]);
  await audit(req.session.userId, 'info', 'file.delete', `Arquivo removido: ${rows[0].original_name}`);
  res.json({ ok: true });
}));

app.get('/api/events', requireAuth, asyncRoute(async (req, res) => {
  const { rows } = await pg.query('SELECT level,action,detail,created_at FROM audit_events WHERE user_id=$1 ORDER BY created_at DESC LIMIT 40', [req.session.userId]);
  res.json({ events: rows });
}));

app.use(express.static(path.join(__dirname, '..', 'public'), { index: 'index.html', maxAge: NODE_ENV === 'production' ? '1h' : 0 }));
app.use((req, res, next) => {
  if (req.method !== 'GET' || req.path.startsWith('/api/') || req.path.startsWith('/guacamole/')) return next();
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});
app.use((err, req, res, next) => {
  if (res.headersSent) return next(err);
  console.error(`[${new Date().toISOString()}] ${req.method} ${req.path}:`, err.stack || err.message);
  if (err instanceof multer.MulterError && err.code === 'LIMIT_FILE_SIZE') return res.status(413).json({ error: `O limite por arquivo é ${Math.round(MAX_UPLOAD / 1024 / 1024)} MB.` });
  const status = err.status || 500;
  const message = status < 500 ? err.message : 'Ocorreu um erro no servidor. Consulte os logs de implantação.';
  res.status(status).json({ error: message, ...(err.code ? { code: err.code } : {}) });
});

(async () => {
  if (!process.env.DATABASE_URL) throw new Error('DATABASE_URL não configurada.');
  if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32) throw new Error('SESSION_SECRET precisa ter ao menos 32 caracteres. Execute scripts/bootstrap.sh.');
  await pg.query('SELECT 1');
  await initDb();
  await fs.promises.mkdir(DATA_ROOT, { recursive: true, mode: 0o700 });
  app.listen(PORT, '0.0.0.0', () => console.log(`Windows Cloud API/web listening on :${PORT}; cloudConfigured=${awsConfigured}; NODE_ENV=${NODE_ENV}`));
})().catch(e => { console.error('Startup failed:', e); process.exit(1); });
