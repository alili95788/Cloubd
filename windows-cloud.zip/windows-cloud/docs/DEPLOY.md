# Guia de implantação real

Este guia configura um gateway web Linux que cria máquinas Windows licenciadas na AWS e as disponibiliza por navegador através do Apache Guacamole. **Não pule a parte de rede/licença/custos.**

## 1. Topologia esperada

- **Gateway Linux**: hospeda Docker Compose, a API, PostgreSQL, Guacamole/guacd e Caddy. Tem IP público fixo e domínio com DNS A/AAAA apontando para ele.
- **Windows EC2**: criada sob demanda em uma subnet privada. Sem IP público. O tráfego RDP chega ao Windows a partir do gateway na mesma VPC/rede roteada.
- **HTTPS**: Caddy termina TLS nas portas 80/443 e encaminha `/api/*` à API e `/guacamole/*` ao Guacamole. Não exponha as portas 3000, 4822 ou 5432 à internet.
- **Arquivos**: a pasta `data/drive/<id-da-conta>` é compartilhada entre API e guacd, e aparece como drive redirecionado no Windows. Isso não dá à interface web acesso livre ao disco inteiro `C:`.

## 2. Preparar o host

Instale Docker Engine e o plugin Docker Compose v2 conforme a documentação oficial da distribuição. Configure firewall para liberar somente TCP 80 e 443 publicamente (SSH apenas de IPs administrativos). Associe um IP estático ao host e crie um registro DNS para o domínio.

Extraia o projeto e execute `./scripts/bootstrap.sh`. Na primeira execução, apenas gera `.env` com segredos aleatórios. Guarde uma cópia segura dos segredos, depois edite o domínio. A chave `DATA_ENCRYPTION_KEY` é crítica: se ela for perdida, as senhas/pares de chaves cifrados das VMs existentes não poderão ser recuperados. Não gere outra chave depois de começar a usar o serviço.

## 3. Criar a rede AWS

1. Use uma VPC com subnet privada capaz de rotear de volta ao gateway Linux. A subnet Windows precisa de saída controlada para atualizações e downloads (por exemplo, NAT Gateway), sem receber conexões RDP públicas.
2. Crie o **security group do Windows** e preencha seu ID em `AWS_WINDOWS_SECURITY_GROUP_ID`. Regra de entrada: TCP `3389`, source **o security group do gateway Linux**, não `0.0.0.0/0`. Mantenha a saída necessária para downloads/Windows Update.
3. Preencha `AWS_SUBNET_ID` com a subnet privada e `AWS_REGION` com a mesma região da rede.
4. Confirme que o servidor consegue alcançar o IP privado dos Windows EC2 na porta 3389 através do caminho de rede da VPC. A aplicação usa o IP privado; uma VPC isolada de outro provedor não serve sem peering/VPN/roteamento seguro.
5. Configure AWS Budgets e alertas para evitar gastos surpresa. Orçamentos/alertas não são uma garantia técnica de bloqueio automático da cobrança.

## 4. IAM para o provisionador

O AWS SDK usa a cadeia padrão de credenciais. Em produção, prefira uma **IAM role vinculada ao host/tarefa** a guardar access keys estáticas em `.env`. A aplicação aceita credenciais AWS estáticas opcionais no `.env` como alternativa, mas só use um usuário dedicado de privilégios mínimos e mantenha o arquivo com permissão `0600`. A role precisa de permissões para ler o parâmetro público SSM da AMI Windows, descrever imagens/instâncias, criar pares de chaves e instâncias, recuperar a senha inicial, iniciar/parar/reiniciar/terminar apenas as instâncias gerenciadas por este sistema e excluir os pares de chaves antigos.

**Nota para credenciais por IAM role:** se o gateway estiver numa EC2 e a API rodar em Docker, valide o acesso seguro ao IMDSv2 a partir do contêiner; a configuração padrão de hop limit pode bloquear a role dentro do Docker. Em serviço gerenciado, prefira uma role de tarefa/serviço. Não resolva isso desativando o IMDSv2.

Conjunto de ações usado pelo código:

- `ssm:GetParameter` para `/aws/service/ami-windows-latest/Windows_Server-2022-English-Full-Base`.
- `ec2:DescribeImages`, `ec2:DescribeInstances`, `ec2:CreateKeyPair`, `ec2:DeleteKeyPair`, `ec2:RunInstances`, `ec2:StartInstances`, `ec2:StopInstances`, `ec2:RebootInstances`, `ec2:TerminateInstances`, `ec2:GetPasswordData`, `ec2:CreateTags` e `cloudwatch:GetMetricStatistics` para CPU/rede.

A AWS possui permissões de recurso diferentes para ações de lançamento e de descrição. Não conceda `AdministratorAccess` ao serviço. Faça uma política própria com escopo restrito à região, AMI, subnet, security group, tipos de instância permitidos e recursos com tags `ManagedBy=WindowsCloud`; valide a política em uma conta de teste antes de expor cadastros. Não há credenciais reais incluídas neste ZIP.

## 5. Finalizar o `.env`

Campos obrigatórios para criar uma VM:

```env
DOMAIN=cloud.seudominio.com
AWS_REGION=us-east-1
AWS_SUBNET_ID=subnet-xxxxxxxx
AWS_WINDOWS_SECURITY_GROUP_ID=sg-xxxxxxxx
AWS_INSTANCE_TYPE=m6i.large
AWS_VOLUME_GIB=80
AWS_WINDOWS_AMI_PARAMETER=/aws/service/ami-windows-latest/Windows_Server-2022-English-Full-Base
```

Mantenha os segredos gerados por `bootstrap.sh` (`SESSION_SECRET`, `DATA_ENCRYPTION_KEY`, `GUAC_JSON_SECRET`, senhas PostgreSQL) e proteja o arquivo com permissões `0600`. Não compartilhe o `.env` nem inclua no Git.

Execute:

```bash
./scripts/bootstrap.sh
docker compose ps
docker compose logs -f app guac caddy
```

O Caddy tenta obter um certificado TLS automático; o domínio precisa resolver publicamente para esse servidor e as portas 80/443 devem estar liberadas. Não use `http://` aberto para contas reais. Para teste local, `DOMAIN=localhost` pode usar certificado local não confiável para outros dispositivos; isso não equivale a produção.

## 6. Testar a primeira VM

1. Abra o domínio HTTPS e crie uma conta com senha forte.
2. Toque em `Ligar meu PC`. O backend resolve a AMI oficial de Windows Server 2022, cria um par de chaves, lança EC2 e mantém o volume EBS entre desligamentos.
3. Aguarde o estado `running`. A AWS pode levar vários minutos até publicar a senha inicial do administrador; o painel informa quando ela está pronta.
4. Toque em `Conectar ao Windows`. O backend cria uma configuração Guacamole JSON temporária criptografada e limitada à sessão daquela conta. A URL dura `REMOTE_TOKEN_HOURS` horas; não a compartilhe.
5. Dentro do Windows, abra o Explorador de Arquivos e procure a unidade redirecionada `WindowsCloud`. Transfira os arquivos enviados pelo painel para pastas do Windows.
6. No navegador dentro da sessão, acesse o site oficial do aplicativo que deseja instalar, baixe o instalador e confirme os requisitos. O catálogo do site é somente catálogo de links, não automação de instalação.
7. Crie um arquivo de teste, desligue a VM pelo painel, ligue novamente e verifique que o arquivo ainda existe no disco persistente do Windows. Esta validação final precisa ser executada na própria conta AWS após a implantação.

## 7. PWA Android

Acesse o domínio no Chrome para Android, abra o menu do navegador e use **Instalar app** ou **Adicionar à tela inicial** se o Chrome oferecer a opção. O service worker armazena apenas a interface estática; não armazena respostas privadas da API nem a sessão remota offline.

## 8. Custos e licença

- A máquina EC2 e o volume EBS são recursos pagos conforme região/configuração/uso; a licença Windows Server é parte da tarifa da AMI Windows elegível, conforme a oferta AWS.
- Uma VM parada ainda pode gerar custos de armazenamento. Uma VM ligada pode continuar gerando custos sem usuário conectado.
- A configuração padrão **não é Windows 10/11 cliente**. Se precisar exatamente de Windows 10/11, escolha um serviço de desktop virtual/provedor com direitos de virtualização adequados e adapte o provisionador; não troque somente a AMI por uma imagem arbitrária.
- Não há garantia de GPU. Antigravity, Codex e outros produtos podem exigir conta, plano, sistema operacional suportado e/ou recursos maiores.

## 9. Encerrar com segurança

- Para parar temporariamente os contêineres mantendo dados: `docker compose down`.
- Para iniciar novamente: `docker compose up -d`.
- Não execute `docker compose down -v` se quiser manter o banco de dados de usuários.
- Excluir a máquina pelo painel termina a EC2 e apaga a unidade de transferência. Faça backup primeiro.
- Antes de remover a implantação, exporte seus dados necessários e remova os volumes somente se tiver certeza de que não precisa mais deles.
