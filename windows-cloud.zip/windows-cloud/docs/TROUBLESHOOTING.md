# Solução de problemas

### O site não abre / certificado TLS não aparece
- Confira o A/AAAA do domínio, o IP do servidor e se TCP 80/443 chegam ao host.
- Execute `docker compose logs -f caddy`.
- Verifique que `DOMAIN` em `.env` é o domínio exato que resolve para o servidor. Certificados públicos não são emitidos para domínios de exemplo nem nomes locais.

### Cadastro/login falha ou mostra erro no servidor
- Execute `docker compose ps` e `docker compose logs -f app db`.
- Confirme que o banco está healthy e que `DATABASE_URL`, `POSTGRES_APP_PASSWORD` e `POSTGRES_PASSWORD` correspondem ao arquivo gerado no primeiro deploy.
- Alterar `POSTGRES_APP_PASSWORD` depois de criar o volume de banco não altera a senha interna do PostgreSQL automaticamente. Faça rotação com comando SQL específico; não apague o volume sem backup.

### Botão Ligar meu PC diz que falta configuração
- Preencha `AWS_REGION`, `AWS_SUBNET_ID` e `AWS_WINDOWS_SECURITY_GROUP_ID` em `.env`; depois `docker compose up -d --force-recreate app`.
- Confira as permissões IAM e `docker compose logs -f app`.
- `AWS_WINDOWS_AMI_PARAMETER` deve apontar para uma AMI pública existente na região escolhida.

### EC2 liga, mas a senha ainda não aparece
- A AWS informa que pode levar vários minutos para a senha administrativa inicial ficar disponível. O painel tenta obtê-la durante a atualização de estado.
- Veja `ec2:GetPasswordData` na política IAM e se o par de chaves cifrado está na linha da máquina no PostgreSQL.
- Não recrie chaves manualmente para uma instância existente; a senha foi cifrada com a chave gerada durante o provisionamento.

### Guacamole abre, mas RDP não conecta
- Verifique se o Windows EC2 está `running` e a senha inicial está pronta.
- Confira que o gateway tem caminho de rede até o IP privado da instância.
- Na regra de entrada do security group Windows, permita TCP 3389 apenas a partir do security group do gateway.
- Verifique `docker compose logs -f guac guacd` e se `GUAC_JSON_SECRET`/`JSON_SECRET_KEY` são idênticos. Se mudar o segredo, links remotos antigos param de autenticar.
- Certifique-se de que a extensão JSON oficial foi baixada pelo `infra/guacamole/Dockerfile` e que a imagem foi reconstruída após mudanças.

### Unidade WindowsCloud não aparece
- Dentro da sessão RDP, abra “Este Computador” e aguarde alguns segundos; se necessário, desconecte e reconecte após o `drive-path` ser criado.
- Confirme que `./data/drive` está montado tanto no serviço `app` quanto em `guacd`.
- Confira permissões da pasta. A API precisa gravar, e o processo `guacd` precisa ler/escrever no diretório da conta.
- O drive compartilhado não é o disco `C:`. Copie os arquivos para o disco da VM quando necessário.

### Um programa não instala ou não abre
- Confirme que o link veio do site oficial, a arquitetura está correta e o Windows remoto é compatível.
- A configuração padrão é Windows Server 2022 Desktop Experience, não Windows 10 cliente. Alguns aplicativos podem recusar a instalação em Windows Server.
- Certas ferramentas exigem conta, assinatura, recursos de hardware, GPU ou privilégios administrativos.

### Como reiniciar serviços sem apagar dados
```bash
docker compose restart app guac guacd caddy
```
Não utilize `docker compose down -v` se quiser conservar os dados do banco.
