# Segurança e limites conhecidos

## Controles implementados

- Senhas de login derivadas com bcrypt e custo 12; o banco nunca armazena a senha de login em texto puro.
- Sessões armazenadas no PostgreSQL, `HttpOnly`, `SameSite=Lax`, `Secure` em produção e `trust proxy` para HTTPS atrás do Caddy.
- Rate limit global e mais restritivo para login/cadastro; verificação do cabeçalho `Origin` em operações de alteração.
- Validação de propriedade por `user_id` em todos os endpoints de máquina/arquivo.
- Senha inicial Windows e material privado do par de chaves cifrados com AES-256-GCM e tag de autenticação.
- Credenciais AWS ficam no ambiente IAM do servidor; não são retornadas ao navegador.
- Autenticação JSON de Guacamole usa assinatura HMAC-SHA256 e AES-128-CBC, com expiração configurável, e contém somente a conexão da máquina daquela conta.
- Guacamole/guacd e PostgreSQL não têm portas publicadas no host; somente Caddy expõe 80/443.
- Instâncias Windows usam IP privado e regra de RDP deve aceitar apenas a origem do gateway.
- Rotas de exclusão exigem confirmação explícita e eventos importantes são auditados.

## Antes de abrir cadastro ao público

1. Restrinja a IAM role às operações, tipos, AMIs, subnets, security groups e tags do serviço. Não use credenciais AWS de administrador.
2. Adicione proteção contra abuso/custos: cotas por usuário, aprovação para provisionar, monitoramento/alertas, limites de duração e política de inatividade.
3. Faça auditoria de segurança e teste de isolamento entre contas, configuração CSP, headers, restauração de backups, dependências e imagens de contêiner.
4. Configure backups cifrados, retenção, recuperação de desastre e um processo de rotação de segredos.
5. Revise retenção de dados, privacidade, termos de uso, licença Windows, requisitos legais, políticas do provedor e como atender solicitações de exclusão.
6. A extensão JSON usa um token/link temporário. Quem obtiver esse link pode tentar abrir a sessão até a expiração, embora o JSON contenha uma configuração cifrada. Não compartilhe o link e mantenha o tempo de validade o menor possível.
7. Os arquivos da unidade `WindowsCloud` são transferências da conta, não um gerenciador completo do disco Windows. O disco EBS da VM e a pasta compartilhada têm políticas distintas.

## Riscos/limitações que não devem ser ocultados

- O código de provisionamento é um protótipo implantável, não um serviço multi-tenant auditado. Não lance publicamente sem revisão.
- Existe um administrador inicial do Windows. Proteja a rede RDP, a API e os segredos; considere criar um usuário Windows não administrador e mudar a configuração RDP antes do uso aberto.
- O estado `running` da EC2 não significa que a interface Windows já terminou de iniciar; a senha pode demorar. O status RDP ainda pode não estar pronto imediatamente.
- O sistema não mede RAM do Windows nem uso real de disco em tempo real por padrão. Isso requer Windows CloudWatch Agent/SSM ou um agente de telemetria com autenticação e configuração adicionais. Não mostre estimativas como métricas reais.
- A operação `Ligar meu PC` pode incorrer em custo. Limites no app não substituem controle de orçamento e monitoramento no provedor.
